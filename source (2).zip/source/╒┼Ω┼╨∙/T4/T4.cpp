#include<bits/stdc++.h>
using namespace std;
int a[500010],tmp[210],maxn,x[210],n;
int main(){
	freopen("T4.in","r",stdin);
	freopen("T4.out","w",stdout);
	cin>>n;
	for(int i = 1;i<=n;i++){
		scanf("%d",&a[i]);
		x[a[i]]++;
		maxn=max(maxn,a[i]);
	}
	for(int i = 1;i<=n;i++){
		memcpy(tmp,x,sizeof(tmp));
		for(int j = n;j>=1;j--){
			int maxt=0,g=0;
			for(int k = 1;k<=maxn;k++){
				if(tmp[k]>maxt){
					g=1;
					maxt=tmp[k];
				}
				else if(tmp[k]==maxt) g++;
			}
			if(g>=2){
				cout<<i<<' '<<j;
				return 0;
			}
			else tmp[a[j]]--;
		}
		x[a[i]]--;
	}
	cout<<"-1";
	return 0;
}

