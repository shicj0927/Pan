#include<bits/stdc++.h>
using namespace std;
int n,q,a[510],ss[30];
string s[510];
int main(){
//	freopen("T3.in","r",stdin);
//	freopen("T3.out","w",stdout);
	cin>>n>>q;
	for(int i = 1;i<=n;i++){
		cin>>a[i];
		s[i]="AAA";
	}
	for(int i = 1;i<=q;i++){
		char x;
		cin>>x;
		if(x=='W'){
			int l,r,t,ans1=0,ans2=0;
			cin>>l>>r>>t;
			for(int j = l;j<=r;j++){
				if(a[j]){
					ans1++;
					if(a[j]<t){
						a[j]=0;
						ans2++;
					}
					else a[j]++;
				}
			}
			cout<<ans1<<' '<<ans2<<endl;
		}
		if(x=='A'){
			int l,r,k,ans=0;
			cin>>l>>r>>k;
			for(int j = l;j<=r;j++){
				if(a[j]==0){
					ans++;
					a[j]=k;
				}
			}
			if(ans==0) cout<<"no add"<<endl;
			else if(ans==1) printf("Add 1 soldier");
			else printf("Add %d soldiers",ans);
		}
		if(x=='C'){
			string t;
			int p,sl=0,l,r;
			cin>>t>>p;
			for(r = 1;r<=n;r++){
				if(s[r]==t){
					l=r;
					while(r<=n&&s[r]==t){
						s[r]+='-';
						r++;
					}
					r--;
				}
			}
			if(p>r-l+1){
				cout<<"ERR"<<endl;
				continue;
			}
			char tmpp1;
			string tmpp2;
			if(t[t.size()-1]=='A'){
				if(ss[1]<9){
					tmpp1='A';
					tmpp2+=char(ss[1]+1+'0');
				}
				else{
					tmpp1='A';
					int tmpp4=ss[1],tmpp3=ss[1],tmpp5=1;
					while(tmpp4){
						tmpp4/=10;
						tmpp5*=10;
					}
					while(tmpp3){
						tmpp2+=char(tmpp3/tmpp5+'0');
						tmpp3%=tmpp5;
						tmpp5/=10;
					}
				}
			}
			else{
				tmpp1=t[t.size()-2];
				if(ss[tmpp1-'A']<9){
					tmpp2+=char(ss[tmpp1-'A']+1+'0');
				}
				else{
					int tmpp4=ss[tmpp1-'A'],tmpp3=ss[tmpp1-'A'],tmpp5=1;
					while(tmpp4){
						tmpp4/=10;
						tmpp5*=10;
					}
					while(tmpp3){
						tmpp2+=char(tmpp3/tmpp5+'0');
						tmpp3%=tmpp5;
						tmpp5/=10;
					}
				}
			}
			int ans=p;
			for(int tt=l;tt<=l+p;tt++){
				if(a[tt]==0) ans--;
				s[tt]+=tmpp1;
				s[tt]+=tmpp2;
			}
			cout<<ans<<endl;
		}
		if(x=='S'){
			int p;
			cin>>p;
			if(a[p]==0){
				cout<<"ERR"<<endl;
			}
			else cout<<s[p]<<endl;
		}
		if(x=='E'){
			string ss;
			int ans=0;
			cin>>ss;
			for(int i = 1;i<=n;i++){
				if(s[i]==ss){
					int j=i;
					while(j<=n&&s[j]==ss){
						if(a[j]!=0) ans++;
					}
				}
			}
			if(ans==0) cout<<"Oh no"<<endl;
			else cout<<ans<<endl;
		}
	}
	return 0;
}

