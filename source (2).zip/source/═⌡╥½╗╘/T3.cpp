#include<bits/stdc++.h>
using namespace std;
const long long maxn=500;
long long q;
struct node{
	string name;
	vector<long long>ren;
}budui[maxn*5+1];
long long number[30],buduishu;
long long n;
struct edge{
long long nengli;
bool cunhuo;
string budui;
}a[maxn+1];
long long read(){
long long sgn=1,num=0;
char ch=getchar();
while(ch<'0'||ch>'9'){
if(ch=='-')sgn=-1;
ch=getchar();
}
while(ch>='0'&&ch<='9'){
num=(num<<3)+(num<<1)+ch-'0';
ch=getchar();
}
return sgn*num;
}
void write(long long n,bool p){
if(n<0){putchar('-');n=-n;}
if(n==0){if(p)putchar('0');
return; }
write(n/10,0);putchar(n%10+'0');
}
string gai(long long a){
	string ret="";
	while(a){
		ret=(char)(a%10+48)+ret;
		a/=10;
	}
	return ret;
}
int main(){
freopen("T3.in","r",stdin);
freopen("T3.out","w",stdout);
cin>>n>>q;
for(int i=1;i<=n;i++){
	cin>>a[i].nengli;
	a[i].cunhuo=true;
	a[i].budui="AAA";
}
budui[1].name="AAA";
for(int i=1;i<=n;i++){
	budui[1].ren.push_back(i);
}
buduishu=1;
while(q--){
	char ch;
	cin>>ch;
	if(ch=='W'){
		long long l,r,t;
		cin>>l>>r>>t;
		long long ans1=0;
		long long ans2=0;
		for(int i=l;i<=r;i++){
			if(a[i].cunhuo==true){
				ans1++;
				if(a[i].nengli<t){
					a[i].cunhuo=false;
					ans2++;
				}
				else{
					a[i].nengli++;
				}
			}
		}
		cout<<ans1<<" "<<ans2<<endl;
	}
	else if(ch=='C'){
		string t;
		long long p;
		cin>>t>>p;
		char jia;
		if(t=="AAA"){
			jia=0;
		}
		else{
			jia=t[t.size()-2]-'A'+1;
		}long long Y=0;
		for(int i=1;i<=buduishu;i++){
			if(budui[i].name==t){
				Y=i;
				break;
			}
		}
		//cout<<Y<<" "<<budui[Y].ren.size()<<endl;
		if(budui[Y].ren.size()<p){
			cout<<"ERR\n";continue;
		}
		else{long long ans=0;
			for(int i=0;i<p;i++){
				if(a[budui[Y].ren[i]].cunhuo==true){
					ans++;
				}
			}
			cout<<ans<<endl;
		}
		buduishu++;
		budui[buduishu].name=budui[Y].name;
		budui[buduishu].name+='-';
		budui[buduishu].name+=(char)(jia+'A');
		number[jia]++;
		budui[buduishu].name+=(string)(gai(number[jia]));
		for(int i=0;i<p;i++)budui[buduishu].ren.push_back(budui[Y].ren[i]);
		for(int i=0;i<p;i++){
			budui[Y].ren.erase(budui[Y].ren.begin(),budui[Y].ren.begin()+1);
		}
	}
	else if(ch=='S'){
		long long p;
		cin>>p;
		if(a[p].cunhuo==false){
			cout<<"ERR\n";
		}
		else{
			for(int i=1;i<=buduishu;i++){
				if(find(budui[i].ren.begin(),budui[i].ren.end(),p)!=budui[i].ren.end()){
					cout<<budui[i].name<<endl;
				}
			}
		}
	}
	else if(ch=='E'){
		long long Y;
		string s;
		cin>>s;
		for(int i=1;i<=buduishu;i++){
			if(budui[i].name==s){
				Y=i;
				break;
			}
		}
		long long ans=0;
		for(int i=0;i<budui[Y].ren.size();i++){
		if(a[budui[Y].ren[i]].cunhuo==true){
		ans++;
		}
		}
		if(ans!=0)cout<<ans<<endl;
		else cout<<"Oh no!\n";
	}
	else if(ch=='A'){
		long long l,r,k,ans=0;
		cin>>l>>r>>k;
		for(int i=l;i<=r;i++){
			if(a[i].cunhuo==true)continue;
			else{
				ans++;
				a[i].cunhuo=true;
				a[i].nengli=k;
			}
		}
		if(ans==0){
			cout<<"no add\n";
		}
		else if(ans==1){
			cout<<"Add 1 soldier\n";
		}
		else cout<<"Add "<<ans<<" soldiers\n";
	}
}
return 0;}
