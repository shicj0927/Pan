#include<bits/stdc++.h>
using namespace std;
const long long maxn=1e3;
long long n,m,k,ans=1145141919810;
long long a[maxn+1];
struct node{
	long long l,c;
}b[20];
bool p[maxn+1];
long long read(){
long long sgn=1,num=0;
char ch=getchar();
while(ch<'0'||ch>'9'){
if(ch=='-')sgn=-1;
ch=getchar();
}
while(ch>='0'&&ch<='9'){
num=(num<<3)+(num<<1)+ch-'0';
ch=getchar();
}
return sgn*num;
}
void write(long long n,bool p){
if(n<0){putchar('-');n=-n;}
if(n==0){if(p)putchar('0');
return; }
write(n/10,0);putchar(n%10+'0');
}
void dfs(long long now,long long sum){
/*	cout<<now<<" "<<sum;
	cout<<"!\n";
	for(int i=1;i<=m;i++){
		cout<<p[i]<<" ";
	}cout<<"?\n";*/
	if(now>k){
		for(int i=1;i<=n;i++){
			if(p[a[i]]==false)return;
		}
		ans=min(ans,sum);
	return;}
	dfs(now+1,sum);
	sum+=b[now].c;
	for(int i=1;i<=m;i++){
		if(i+b[now].l-1>m){
			continue;
		}
		bool flag=false;
		for(int j=i;j<=min(i+b[now].l-1,m);j++){
			if(p[j]==true){
				flag=true;
				break;
			}
		}
		if(flag)continue;
	    for(int j=i;j<=min(i+b[now].l-1,m);j++){
	     p[j]=true;
	    }
		dfs(now+1,sum);
		for(int j=i;j<=min(i+b[now].l-1,m);j++){
			p[j]=false;
		}
	}
}
int main(){
	freopen("T1.in","r",stdin);
	freopen("T1.out","w",stdout);
	n=read();m=read();k=read();
	for(int i=1;i<=n;i++){
		a[i]=read();
	}
	sort(a+1,a+n+1);
	for(int i=1;i<=k;i++){
		b[i].l=read();b[i].c=read();
	}
	dfs(1,0);
	if(ans==1145141919810)cout<<"poor A!";
	else
	write(ans,true);
return 0;}
