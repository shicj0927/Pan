#include<bits/stdc++.h>
using namespace std;
const long long maxn=1e3;
long long n,a[maxn+1];
long long read(){
long long sgn=1,num=0;
char ch=getchar();
while(ch<'0'||ch>'9'){
if(ch=='-')sgn=-1;
ch=getchar();
}
while(ch>='0'&&ch<='9'){
num=(num<<3)+(num<<1)+ch-'0';
ch=getchar();
}
return sgn*num;
}
void write(long long n,bool p){
if(n<0){putchar('-');n=-n;}
if(n==0){if(p)putchar('0');
return; }
write(n/10,0);putchar(n%10+'0');
}
struct node{
	long long a,b,c,d;
};
long long ans;
map<vector<double>,bool>p;
bool pan(vector<double>g){
	double A=g[0],B=g[1],C=g[2],D=g[3];
	double yi,er,san;
	yi=B-A;
	er=C-B;
	san=D-C;
	if(yi==er&&er==san&&yi==san){
		return true;
	}
	yi=B/A;
	er=C/B;
	san=D/C;
	if(yi==er&&er==san&&yi==san){
		return true;
	}
	return false;
}
int main(){
freopen("T2.in","r",stdin);
freopen("T2.out","w",stdout);
n=read();
for(int i=1;i<=n;i++){
	a[i]=read();
}
sort(a+1,a+n+1);
for(int A=1;A<=n;A++){
	for(int b=A+1;b<=n;b++){
		for(int c=b+1;c<=n;c++){
			for(int d=c+1;d<=n;d++){
					vector<double>v;
					v.clear();
					v.push_back(a[A]);
					v.push_back(a[b]);
					v.push_back(a[c]);
					v.push_back(a[d]);
					if(p[v]==true)continue;
					else p[v]=true;
					if(pan(v)){
					//	cout<<v[0]<<" "<<v[1]<<" "<<v[2]<<" "<<v[3]<<"!\n";
					ans++;}
			}
		}
	}
}write(ans,true);
return 0;}
