#include<bits/stdc++.h>
using namespace std;
#define int long long
const int N=1e3+10;
struct node{
	int l,c;
}q[15];
int n,m,k,a[N],vis[15],minn=1e18;
void dfs(int i,int now,int cnt){
	if(i==n+1){
		minn=min(minn,cnt);
		return;
	}
	if(a[i]<=now){
		dfs(i+1,now,cnt);
		return;
	}
	for(int j=1;j<=k;j++){
		if(!vis[j]){
			if(a[i]+q[j].l-1>m){
				if(now+q[j].l<=m){
					vis[j]=1;
					dfs(i+1,m,cnt+q[j].c);
					vis[j]=0;
				}	
				continue;
			}
			vis[j]=1;
			dfs(i+1,a[i]+q[j].l-1,cnt+q[j].c);
			vis[j]=0;
		}
	}
	return;
}
signed main(){
	freopen("T1.in","r",stdin);
	freopen("T1.out","w",stdout);
	cin>>n>>m>>k;
	for(int i=1;i<=n;i++)
		cin>>a[i];
	sort(a+1,a+n+1);
	for(int i=1;i<=k;i++)
		cin>>q[i].l>>q[i].c;
	dfs(1,0,0);
	if(minn==1e18) cout<<"poor A!";
	else cout<<minn;
}
/*
10 50 10
4 5 6 7 27 28 33 34 35 50 
50 100
49 110
10 5
5 1
3 1 
20 50
70 5
109 4
30 666
25  114514
*/
//151741

