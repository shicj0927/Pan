#include<iostream>
#include<map>
using namespace std;
const int N=1005;
int a[N];
map<int,int>mp;
map<int,int>vis;
int main(){
	freopen("T2.in","r",stdin);
	freopen("T2.out","w",stdout);
	int n,cnt=0;
	cin>>n;
	for(int i=1;i<=n;i++){
		cin>>a[i];
		mp[a[i]]++;
	}
	for(int i=1;i<=n;i++){
		if(!vis[a[i]]){
			cnt+=mp[a[i]]*(mp[a[i]]-1)*(mp[a[i]]-2)*(mp[a[i]]-3)/24;
			vis[a[i]]=1;
		}
	}
	for(int i=1;i<=n;i++){
		for(int j=1;j<=n;j++){
			if(i==j) continue;
			if(a[j]%a[i]==0){
				int x=a[j]*a[j]/a[i];
				if(x<=1e9){
					int y=x*a[j]/a[i];
					if(x!=y) cnt+=mp[x]*mp[y];
				}
			}
			if(a[j]>a[i]) cnt+=mp[a[j]+a[j]-a[i]]*mp[a[j]+a[j]+a[j]-a[i]-a[i]];
		}
	}
	cout<<cnt;
}
/*
10
104 394 756 800 1600 3200 6400 9600 12800 20000
*/
