#include <bits/stdc++.h>
using namespace std;
#define N 1005
#define int long long
#define debug cout<<"**debug**\n";
#define pii pair<int,int>
#define endl '\n'
#define For(i,l,r) for(int i=l,i##end=r;i<=i##end;++i)
#define Rof(i,l,r) for(int i=l,i##end=r;i>=i##end;--i)
template <typename T> inline void rd(T &x){x = 0; bool f = true; char ch = getchar();while(ch < '0' || ch > '9')
{ if(ch == '-') f = false; ch = getchar();}while(ch >= '0' && ch <= '9'){ x = (x << 1) + (x << 3) + (ch ^ '0'); ch = getchar();}if(!f) x = -x;}
template <typename T, typename ...Args> inline void rd(T &x, Args &...args){ rd(x); rd(args...);}
int dp[N][1<<10];
int a[N],l[N],c[N];
bool vis[N];
void solve(){
	int n, m, K;
	cin>>n>>m>>K;
	For(i, 1, n) cin>>a[i],vis[a[i]]=1;
	For(i, 1, K) cin>>l[i]>>c[i];
	For(i, 1, m){
		For(j, 0, (1<<K)-1){
			dp[i][j]=1e9;
			if (!vis[i]) dp[i][j]=dp[i-1][j];
			For(k, 1, K){
				if (j&(1<<(k-1))&&i>=l[k])dp[i][j]=min(dp[i][j],dp[i-l[k]][j^(1<<(k-1))]+c[k]);
			}
		}
	}
	int ans=1e9;
	For(i, 0, (1<<K)-1) ans=min(ans, dp[m][i]);
	if (ans==1e9) return cout<<"poor A!\n",void();
	cout<<ans<<endl;
}
signed main(){
	freopen("T1.in","r",stdin);
	freopen("T1.out","w",stdout);
//	ios::sync_with_stdio(0), cin.tie(0), cout.tie(0);
	solve();
	return 0;
}

