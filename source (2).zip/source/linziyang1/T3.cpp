#include <bits/stdc++.h>
using namespace std;
#define N 2900001
#define int long long
#define debug cout<<"**debug**\n";
#define pii pair<int,int>
#define endl '\n'
#define For(i,l,r) for(int i=l,i##end=r;i<=i##end;++i)
#define Rof(i,l,r) for(int i=l,i##end=r;i>=i##end;--i)
template <typename T> inline void rd(T &x){x = 0; bool f = true; char ch = getchar();while(ch < '0' || ch > '9')
{ if(ch == '-') f = false; ch = getchar();}while(ch >= '0' && ch <= '9'){ x = (x << 1) + (x << 3) + (ch ^ '0'); ch = getchar();}if(!f) x = -x;}
template <typename T, typename ...Args> inline void rd(T &x, Args &...args){ rd(x); rd(args...);}
struct Soldier{
	int health,no;
	int tm;
	bool dead;
	bool operator < (const Soldier y) const {
		return no<y.no;
	}
};
struct Force{
	int no;
	string name;
	Force* fa;
	set<Soldier*> army;
	int cnt;
	char lst;
};
map<int,Force*> force;
map<int,Soldier*> soldier;
map<string,int> id;
int cnt=0;
void solve(){
	char op;
	cin>>op;
	if (op=='W') {
		int l, r, t;
		cin>>l>>r>>t;
		int ans1=0,ans2=0;
		For(i, l, r) {
			if (!soldier[i]->dead) ++ans1;
		}
		For(i, l, r){
			if (soldier[i]->health<t) soldier[i]->dead=1,++ans2;
			else ++soldier[i]->health;
		}
		cout<<ans1<<' '<<ans2<<endl;
	}else if (op=='C'){
		string nm;cin>>nm;
		int num;cin>>num;
		Force* faa=force[id[nm]];
		Force* now=new Force;
		now->no=++cnt;
		now->name=faa->name+"-";
		now->name.push_back((char)(faa->lst+1));
		now->name+=to_string(++faa->cnt);
		now->fa=faa;
		now->lst=faa->lst+1;
		now->cnt=0;
		set<Soldier*> del;
		del.clear();
		int ans11=0;
		for (Soldier* it:faa->army){
			if (num) {
				if (!it->dead) ++ans11;
				del.insert(it),--num;
			}
			else break;
		}
		if (num) {
			return cout<<"ERR\n",void();
		}
		cout<<ans11<<endl;
		for (Soldier* it:del){
			it->tm=now->no;
			faa->army.erase(it);
			now->army.insert(it);
		}
		id[now->name]=now->no;
		force[now->no]=now;
	}else if (op=='S'){
		int no;
		cin>>no;
		Soldier* now=soldier[no];
		int ans=0;
		for (Soldier* it:force[now->tm]->army){
			++ans;
			if (it->no==now->no) break;
		}
		if (now->dead) cout<<"ERR\n";
		else cout<<force[now->tm]->name/*<<' '<<ans<<' '<<now->health*/<<endl;
	}else if (op=='E'){
		string nm;cin>>nm;
		int cntt=0;
		for (Soldier* it:force[id[nm]]->army){
			if (!it->dead) ++cntt;
		}
		if (cntt) cout<<cntt<<endl;
		else cout<<"Oh no!\n";
	}else if (op=='A'){
		int l, r, k;
		cin>>l>>r>>k;
		int cntt=0;
		For(i, l, r){
			if (soldier[i]->dead) {
				soldier[i]->dead=0;
				soldier[i]->health=k;
				++cntt;
			}
		}
		if (!cntt) cout<<"no add\n";
		else if (cntt==1) cout<<"Add 1 soldier\n";
		else cout<<"Add "<<cntt<<" soldiers\n";
	}
}
signed main(){
//	ios::sync_with_stdio(0), cin.tie(0), cout.tie(0);
	freopen("T3.in","r",stdin);
	freopen("T3.out","w",stdout);
	int n, q;
	cin>>n>>q;
	id["AAA"]=0;
	force[0]=new Force;
	force[0]->no=0,force[0]->name="AAA",force[0]->fa=NULL,force[0]->cnt=0,force[0]->lst='A'-1;
	For(i, 1, n){
		Soldier* now=new Soldier;
		now->no=i;
		now->tm=now->dead=0;
		cin>>now->health;
		soldier[i]=now;
		force[0]->army.insert(now);
	}
	while (q--) solve();
	return 0;
}

