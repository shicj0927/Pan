#include<bits/stdc++.h>
using namespace std;
#define int long long
const int maxn=2005;
const int inf=1e18;
const int V=1e15;
int f[maxn][maxn],g[maxn][maxn];
int c[maxn],l[maxn];
bool vis[maxn];
signed main(){
	freopen("T1.in","r",stdin);
	freopen("T1.out","w",stdout);
	ios::sync_with_stdio(false),cin.tie(NULL),cout.tie(NULL);
	int n,m,k;
	cin>>n>>m>>k;
	for(int i=1;i<=n;i++){
		int x;cin>>x;
		vis[x]=1;
	}
	for(int i=0;i<k;i++){
		cin>>l[i]>>c[i];
	}
	for(int i=0;i<=m;i++){
		for(int j=0;j<(1<<k);j++){
			f[i][j]=inf;
			g[i][j]=inf;
		}
	}
	f[0][0]=g[0][0]=0;
	for(int i=1;i<=m;i++){
		for(int j=1;j<(1<<k);j++){
			for(int t=0;t<k;t++){
				if(((j>>t)&1)&&l[t]<=i){
					int lst=(j^(1<<t));
					int wz=i-l[t]+1;
					f[i][j]=min(f[i][j],c[t]+g[wz-1][lst]);
				}
			}
		}
		for(int j=0;j<(1<<k);j++){
			if(vis[i]){
				g[i][j]=f[i][j];
			}else{
				g[i][j]=min(g[i-1][j],f[i][j]);
			}
		}
	}
	int ans=inf;
	for(int i=0;i<(1<<k);i++){
		ans=min(ans,g[m][i]);
	}
	cout<<ans<<endl;
	return 0;
}
