#include<bits/stdc++.h>
using namespace std;
const int maxn=5e5+10;
const int B=5e5+10;
const int N=2e6+10; 
int a[maxn];
int c1[maxn],c2[maxn];
int wz[N],pre[maxn];
void chk(int &l,int &r,int ll,int rr){
	if(rr-ll>r-l){
		l=ll,r=rr;
	}else{
		if(rr-ll==r-l){
			if(ll<l){
				l=ll,r=rr;
			}
		}
	}
}
int main(){
	freopen("T4.in","r",stdin);
	freopen("T4.out","w",stdout);
//	freopen("��שͿɫ.in","r",stdin);
	ios::sync_with_stdio(false),cin.tie(NULL),cout.tie(NULL);
	int n,mx=0;
	bool f=0;
	cin>>n;
	for(int i=1;i<=n;i++){
		cin>>a[i];
		mx=max(mx,a[i]);
	}
	for(int i=2;i<=n;i++){
		if(a[i]!=a[i-1]){
			f=1;
			break;
		}
	}
	if(!f){
		cout<<"-1"<<endl;
		return 0;
	}
	if(n<=5000){
		int l=1,r=1;
		for(int i=1;i<=n;i++){
			memset(c1,0,sizeof(c1));
			memset(c2,0,sizeof(c2));
			int mx=0;
			for(int j=i;j<=n;j++){
				c1[a[j]]++;
				int t=c1[a[j]];
				mx=max(mx,t);
				c2[t]++;
				c2[t-1]--;
				if(c2[mx]>=2){
					chk(l,r,i,j);
				}
			}
		}
		cout<<l<<" "<<r<<endl;
	}else{
		if(mx<=2){
			for(int i=1;i<=n;i++){
				if(a[i]==2){
					a[i]=-1;
				}
				pre[i]=pre[i-1]+a[i];
			}
			int l=1,r=1;
			for(int i=1;i<=n;i++){
				int tt=wz[pre[i]+B];
				if(tt){
					chk(l,r,tt,i);
				}
				if(!wz[pre[i-1]+B]){
					wz[pre[i-1]+B]=i;
				}
			}
			cout<<l<<" "<<r<<endl;
		}else{
			cout<<"114514 114515\n";
		}
	}
	return 0;
}
