#include<bits/stdc++.h>
using namespace std;
const int maxn=505;
#define sz(x) ((int)(x.size()))
string bd[maxn];
int jy[maxn];
bool al[maxn];
struct jg{
	vector<string> nxt;
	vector<int>sol;
	bool operator <(const jg &y)const{
		return 1;
	}
};
map<string,jg>mp;
string to_s(int x){
	string s="";
	while(x){
		s=char(x%10+'0')+s;
		x/=10;
	}
	return s;
}
int main(){
	freopen("T3.in","r",stdin);
	freopen("T3.out","w",stdout);
	ios::sync_with_stdio(false),cin.tie(NULL),cout.tie(NULL);
	int n,q;
	cin>>n>>q;
	for(int i=1;i<=n;i++){
		mp["AAA"].sol.push_back(i);
	}
	for(int i=1;i<=n;i++){
		bd[i]="AAA";
	}
	for(int i=1;i<=n;i++){
		cin>>jy[i];
	}
//	cout<<"haha"<<endl;
	while(q--){
		char op;cin>>op;
		if(op=='W'){
			int l,r,t,x=0,y=0;
			cin>>l>>r>>t;
			for(int i=l;i<=r;i++){
				if(al[i]){
					continue;
				}
				x++;
				if(jy[i]<t){
					y++;
					al[i]=1;
				}else{
					jy[i]++;
				}
			}
			cout<<x<<" "<<y<<endl;
		}else{
			if(op=='C'){
				string s,st="";
				int num;
				cin>>s>>num;
				int t=sz(mp[s].nxt);
			//	cout<<"Nice"<<endl;
				if(s=="AAA"){
					st="AAA-A";
					st+=to_s(t+1);
		//			cout<<"?? "<<st<<endl;
				}else{
					for(int i=sz(s)-1;i>=0;i--){
						if(s[i]>='A'&&s[i]<='Z'){
							st=s+"-";
							st+=(s[i]+1);
							st+=to_s(t+1);
							break;
						}
					}
				}
				if(sz(mp[s].sol)<num){
					cout<<"ERR"<<endl;
					continue;
				}
			//	cout<<"OK"<<endl;
				mp[s].nxt.push_back(st);
				vector<int>l1,l2;
				for(int i=0;i<num;i++){
					l1.push_back(mp[s].sol[i]);
				}
				for(int i=num;i<sz(mp[s].sol);i++){
					l2.push_back(mp[s].sol[i]);
				}
				mp[s].sol=l2;
		//		cout<<"!! "<<st<<" "<<sz(l1)<<endl;
				mp[st].sol=l1;
				int cc=0;
				for(int t:l1){
					bd[t]=st;
					if(!al[t]){
						cc++;
					}
				}
				cout<<cc<<endl;
			}else{
				if(op=='S'){
					int id;
					cin>>id;
					if(al[id]){
						cout<<"ERR"<<endl;
					}else{
						cout<<bd[id]<<endl;
					}
				}else{
					if(op=='E'){
						string s;
						cin>>s;
						vector<int>lis=mp[s].sol;
						int cnt=0;
						for(int t:lis){
							if(!al[t]){
								cnt++;
							}
						}
						if(!cnt){
							cout<<"Oh no!"<<endl;
						}else{
							cout<<cnt<<endl;
						}
					}else{
						int l,r,k,tot=0;
						cin>>l>>r>>k;
						for(int i=l;i<=r;i++){
							if(al[i]){
								al[i]=0;
								jy[i]=k;
								tot++;
							}
						}
						if(!tot){
							cout<<"no add"<<endl;
						}else{
							cout<<"Add "<<tot<<" soldier";
							if(tot>1){
								cout<<"s";
							}
							cout<<endl;
						}
					}
				}
			}
		}
	}
	return 0;
}
