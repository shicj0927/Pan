//134100
#include <bits/stdc++.h>
const int N = 1005;
int n, a[N];
std::map <int, int> mp; 
long long sum;
int main() {
	freopen("T2.in", "r", stdin);
	freopen("T2.out", "w", stdout);
	scanf("%d", &n);
	for (int i = 1; i <= n; i++)
		scanf("%d", a + i);
	std::sort(a + 1, a + 1 + n);
	for (int i = 1; i <= n; i++)
		mp[a[i]] = i;
	for (int i = 1; i <= n; i++)
		for (int j = i + 1; j <= n; j++) {
			if (a[j] == 0 || a[i] == 0) continue;
			if (a[j] % a[i] != 0) continue;
			int d = a[j] / a[i];
			int k = mp[(int)(d * a[j])];
			if (!k) continue;
			if (k && k > j) {
				int w = mp[(int)(d * a[k])];
				if (w > k)
					sum++;
			}
		}
	for (int i = 1; i <= n; i++)
		for (int j = i + 1; j <= n; j++) {
			if (a[i] == 0 || a[j] == 0) continue;
			int d = a[j] - a[i];
			int k = mp[(int)(d + a[j])];
			if (!k) continue;
			if (k > j) {
				int w = mp[(int)(d + a[k])];
				if (w && w > k)
					sum++;
			}
		}
	printf("%d", sum);
	return 0;
}

