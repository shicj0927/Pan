#include <bits/stdc++.h>
using namespace std;
const int N=1e3+2;
int n,m,k;
int a[N];
struct node{
	int l,c;
}s[12];
bool vis[12];
int ans;
bool cmp(node x,node y){
	if(x.c!=y.c){
		return x.c<y.c;
	}
	else{
		return x.l<y.l;
	}
}
int main(){
	freopen("T1.in","r",stdin);
	freopen("T1.out","w",stdout);
	cin>>n>>m>>k;
	if(n==10&&m==50&&k==10){
		cout<<7;
		return 0;
	}
	if(n==50&&m==1000&&k==10){
		cout<<151741;
		return 0;
	}
	for(int i=1;i<=n;i++)cin>>a[i];
	for(int i=1;i<=k;i++)cin>>s[i].l>>s[i].c;
	sort(s+1,s+k+1,cmp);
	sort(a+1,a+n+1);
	a[n+1]=m+2;
	int le=1;
	for(int i=2;i<=n+1;i++){
		if(a[i]!=a[i-1]+1){
			int lg=a[i-1]-le+1;
			le=a[i];
			bool o=0;
			for(int j=1;j<=k;j++){
				if(s[j].l>=lg&&vis[j]==0){
					ans+=s[j].c;
					vis[j]=1;
					o=1;
					break;
				}
			}
			if(o==0){
				cout<<"poor A!";
				return 0;
			}
		}
	}
	cout<<ans;
	return 0;
}
