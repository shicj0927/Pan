#include<bits/stdc++.h>
using namespace std;
double n,a[1005],sc,sb;
int main(){
	cin>>n;
	for(double i=1;i<=n;i++){
		cin>>a[(int)i];
	}
	sort(a+1,a+1+(int)n);
	for(int i=4;i<=n;i++){
		double cha;
		for(int j=i-1;j>=3;j--){
			cha=a[i]-a[j];
			double now=a[j],num=0;
			for(int h=j-1;h>=1;h--){
				if(now-a[h]>cha){
					break;
				}
				if(now-a[h]==cha){
					num++;now=a[h];
					if(num==2){
						sc++;break;
					}
				}
			}
		}
	}
	for(int i=4;i<=n;i++){
		double bi;
		for(int j=i-1;j>=3;j--){
			bi=a[i]/a[j];
			double now=a[j],num=0;
			for(int h=j-1;h>=1;h--){
				if(now/a[h]>bi){
					break;
				}
				if(now/a[h]==bi){
					num++;now=a[h];
					if(num==2){
						sb++;break;
					}
				}
			}
		}
	}
	cout<<sb+sc;
	return 0;
}
