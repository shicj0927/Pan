#include<bits/stdc++.h>
using namespace std;
int n,a[100005],k[205],kk[205],maxa=-1,maxx,sum; 
int main(){
	cin>>n;cout<<n;
	for(int i=1;i<=n;i++){
		scanf("%d",&a[i]);
		maxa=max(maxa,a[i]);
		kk[a[i]]++;
	}
	for(int ll=n;ll>=2;ll--){cout<<1;
		for(int i=1;i<=maxa;i++){
			k[i]=kk[i];
		}
		for(int i=n;i>ll;i--){
			k[a[i]]--;
		}
		for(int l=1;l+ll-1<=n;k[a[l]]--,k[a[l+ll]]++,l++){
			maxx=-1,sum=0;
			for(int i=1;i<=maxa;i++){
				if(k[i]==0)continue;
				if(k[i]>maxx){
					maxx=k[i];sum=1;
				} 
				else if(k[i]==maxx)sum++;
			}
			if(sum>1){
				cout<<l<<" "<<l+ll-1;return 0;
			}
		}
	}
	cout<<-1;
	return 0;
}
