#include<bits/stdc++.h>
#define MAXN 1005
using namespace std;
long long read(){long long x=0,sgn=1;char ch=getchar();while(ch<'0'||ch>'9'){if(ch=='-')sgn=-1;ch=getchar();}while(ch>='0'&&ch<='9'){x=(x<<3)+(x<<1)+(ch&15);ch=getchar();}return x*sgn;}
void write(long long n,bool p){if(n<0){putchar('-');n=-n;}if(n==0){if(p)putchar('0');return;}write(n/10,0);putchar(n%10+'0');}
long long n,a[1005],ans,k,tot,x,y,cntx,cnty;
struct node{
	long long num,cnt;
}t[1005];
long long fin(long long b){
	long long l=1,r=k,mid;
	while(l<r){
		mid=l+r>>1;
		if(t[mid].num<b)l=mid+1;
		else r=mid;
	}
	if(t[l].num==b)return t[l].cnt;
	else return 0;
}
int main(){
	freopen("T2.in","r",stdin);
	freopen("T2.out","w",stdout);
	n=read();
	for(int i=1;i<=n;i++)a[i]=read();
	sort(a+1,a+n+1);
	tot=1;
	for(int i=2;i<=n;i++){
		if(a[i]==a[i-1])tot++;
		else{
			t[++k].num=a[i-1];
			t[k].cnt=tot;
			tot=1;
		}
	}
	t[++k].num=a[n];
	t[k].cnt=tot;
	//for(int i=1;i<=k;i++)printf("%lld %lld\n",t[i].num,t[i].cnt);
	for(int i=1;i<=k;i++){
		if(t[i].cnt>=4){
			ans+=t[i].cnt*(t[i].cnt-1)*(t[i].cnt-2)*(t[i].cnt-3)/24;
		}
	}
	for(int i=1;i<k;i++){
		for(int j=i+1;j<=k;j++){
			//if(i==j)continue;
			
			x=t[i].num+t[i].num-t[j].num;
			y=t[j].num+t[j].num-t[i].num;
			cntx=fin(x);cnty=fin(y);
			//if(cntx!=0&&cnty!=0)printf("%lld %lld %lld %lld %lld\n",x,t[i].num,t[j].num,y,cntx*cnty*t[i].cnt*t[j].cnt);
			ans+=cntx*cnty*t[i].cnt*t[j].cnt;
			if(abs(t[i].num)==abs(t[j].num)){
				//if(t[i].cnt>=2&&t[j].cnt>=2)printf("%lld %lld %lld\n",t[i].num,t[j].num,t[i].cnt*(t[i].cnt-1)*t[j].cnt*(t[j].cnt-1)/4);
				ans+=t[i].cnt*(t[i].cnt-1)*t[j].cnt*(t[j].cnt-1)/4;
				continue;
			}
			if(t[i].num==0||t[j].num==0)continue;
			x=t[i].num*t[i].num/t[j].num;
			if(x*1.0!=t[i].num*1.0*t[i].num/t[j].num)continue;
			y=t[j].num*t[j].num/t[i].num;
			if(y*1.0!=t[j].num*1.0*t[j].num/t[i].num)continue;
			cntx=fin(x);cnty=fin(y);
			ans+=cntx*cnty*t[i].cnt*t[j].cnt;
		}
	}
	printf("%lld",ans);
	return 0;
}
