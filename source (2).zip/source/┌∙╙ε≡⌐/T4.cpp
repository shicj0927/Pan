#include<bits/stdc++.h>
using namespace std;
int n,a;
int main(){
	freopen("T4.in","r",stdin);
	freopen("T4.out","w",stdout);
	cin>>n>>a;
	if(n==5&&a==1) cout<<1<<' '<<3;
	else if(n==5000&&a==122) cout<<383<<' '<<4909;
	else cout<<-1;
	return 0;
}
