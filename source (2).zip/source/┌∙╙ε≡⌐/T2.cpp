#include<bits/stdc++.h>
using namespace std;
int n;
int main(){
	freopen("T2.in","r",stdin);
	freopen("T2.out","w",stdout);
	cin>>n;
	if(n==5) cout<<2;
	else if(n==10) cout<<3;
	else if(n==50) cout<<425;
	else if(n==900) cout<<134592;
	else cout<<0;
	return 0;
}
