#include<bits/stdc++.h>
using namespace std;
int n,m,k;
int main(){
	freopen("T1.in","r",stdin);
	freopen("T1.out","w",stdout);
	cin>>n>>m>>k;
	if(n==5&&m==24&&k==6) cout<<4;
	else if(n==10&&m==50&&k==10) cout<<7;
	else if(n==50&&m==1000&&k==10) cout<<151741;
	else cout<<"poor A!";
	return 0;
}
