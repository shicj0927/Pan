#include<bits/stdc++.h>
using namespace std;
int n,sum;
int a[10000];
int main(){
	freopen("T2.in","r",stdin);
	freopen("T2.out","w",stdout);
	cin>>n;
	for(int i=0;i<n;i++){
		cin>>a[i];
	}
	sort(a,a+n);
	for(int i=0;i<n;i++){
		for(int j=0;j<n;j++){
			int f1,f2=a[j]-a[i];
			int f11=0,f22=0,f33=0,f44=0;
			for(int k=0;k<n;k++){
				if(a[j]*a[j]==a[k]*a[i]&&i!=j&&j!=k){
					f11=1;
				}
				if(a[j]*a[j]*a[j]==a[k]*a[i]*a[i]&&f11==1&&i!=j&&j!=k){
					f22=1;
				}
				if(a[j]+f2==a[k]&&i!=j&&j!=k){
					f33=1;
				}
				if(a[j]+f2+f2==a[k]&&f33==1&&i!=j&&j!=k){
					f44=1;
				}
			}
			if(f11==1&&f22==1||f33==1&&f44==1){
				sum++;
			}
		}
	}
	cout<<sum;
	return 0;
}

