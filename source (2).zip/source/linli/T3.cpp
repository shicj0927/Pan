#include<bits/stdc++.h>
using namespace std;
int n,q,sum,vis[100];
char f;
struct id{
	string fh;
	int num;
}a[10000];
int main(){
	freopen("T3.in","r",stdin);
	freopen("T3.out","w",stdout);
	int l,r,t,p;
	cin>>n>>q;
	for(int i=1;i<=n;i++){
		cin>>a[i].num;
		a[i].fh="AAA";
	}
	while(q--){
		cin>>f;
		if(f=='W'){
			cin>>l>>r>>t;
			int c=r-l+1,c1=0;
			for(int i=l;i<=r;i++){
				if(a[i].num<0){
					c--;
					c1--;
				}
				a[i].num-=t;
				if(a[i].num<0){
					c1++;
				}else{
					a[i].num++;
				}
			}
			cout<<c<<" "<<c1<<endl;
		}
		if(f=='S'){
			cin>>p;
			if(a[p].num<0){
				cout<<"ERR"<<endl;
			}
			else{
				cout<<a[p].fh<<" "<<endl;
			}
		}
		if(f=='E'){
			string s;
			int qq=0;
			cin>>s;
			for(int i=1;i<=n;i++){
				if(a[i].fh==s){
					qq++;
				}
			}
			if(qq==0){
				cout<<"Oh no!"<<endl;
			}
			else{
				cout<<qq<<endl;
			}
		}
		if(f=='A'){
			int k,k1=0;
			cin>>l>>r>>k;
			for(int i=l;i<=r;i++){
				if(a[i].num<0){
					a[i].num=k;
					k1++;
				}
			}
			if(k1==1){
				cout<<"Add "<<1<<" soldier"<<endl;
			}
			else if(k1==0){
				cout<<"no add"<<endl;
			}
			else{
				cout<<"Add "<<r-l+1<<" soldiers"<<endl;
			}
		}
		if(f=='C'){
			string tt;
			cin>>tt>>p;
			int qwe=0,qqq=0;
			for(int i=1;i<=n;i++){
				if(a[i].fh==tt){
					qwe++;
				}
			}
			if(p>qwe){
				cout<<"ERR"<<endl;
			}
			else{
				for(int i=1;i<=n;i++){
				if(a[i].fh==tt&&p>0){
					p--;
					if(a[i].num>=0){
						qqq++;	
					}
					
					if(tt=="AAA"){
						a[i].fh+="-A";
						a[i].fh+=char(vis['A']+'0'+1);
					}
					else{
						a[i].fh+='-';
						a[i].fh+=char(int(tt[tt.size()-2])+1);
						a[i].fh+=char(vis[tt[tt.size()-2]+1]+'0'+1);	
					}
				}
				
			}
			vis[tt[tt.size()-2]]++;
			cout<<qqq<<endl;
		}
			
			
		}
	}
	return 0;
}

