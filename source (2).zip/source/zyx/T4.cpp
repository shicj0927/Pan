#include<bits/stdc++.h>
#define int long long
#define debug printf("AKIOI\n")
using namespace std;
int read(){
	char c(getchar());
	int x(0),f(1);
	for(;c<'0'||c>'9';){
		if(c=='-') f=-1;
		c=getchar();
	}
	for(;c>='0'&&c<='9';) x=x*10+c-'0',c=getchar();
	return f*x;
}
void write(int x){
	if(x<0) putchar('-'),x=-x;
	if(x>9) write(x/10);
	putchar(x%10+'0');
}
void write(int x,char c){
	write(x);putchar(c);
}
void file(){
	freopen("a.txt","w",stdout);
}
const int N=5005,V=205;
int n,a[N],s[N][V],cnt[V],ans=-1,l,r;
signed main(){
	freopen("T4.in","r",stdin);
	freopen("T4.out","w",stdout);
	n=read();
	for(int i=1;i<=n;i++){
		a[i]=read();s[i][a[i]]++;
	}
	for(int i=1;i<=n;i++){
		for(int j=0;j<=200;j++) s[i][j]+=s[i-1][j];
	}
	for(int i=1;i<=n;i++){
		for(int j=i+1;j<=n;j++){
			for(int k=0;k<=200;k++) cnt[k]=s[j][k]-s[i-1][k];
			sort(cnt,cnt+201,greater<int>());
			int k=1;
			for(;k<=V&&cnt[k]==cnt[k-1];k++);
			k--;
			if(k>0){
				if(j-i+1>ans){
					ans=j-i+1;l=i;r=j;
				}
				else if(j-i+1==ans&&i<l){
					l=i;r=j;
				}
			}
		}
	}
	if(ans==-1) write(-1,'\n');
	else write(l,' '),write(r,'\n');
	return 0;
}
