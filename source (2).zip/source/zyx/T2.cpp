#include<bits/stdc++.h>
#define int long long
#define debug printf("AKIOI\n")
using namespace std;
int read(){
	char c(getchar());
	int x(0),f(1);
	for(;c<'0'||c>'9';){
		if(c=='-') f=-1;
		c=getchar();
	}
	for(;c>='0'&&c<='9';) x=x*10+c-'0',c=getchar();
	return f*x;
}
void write(int x){
	if(x<0) putchar('-'),x=-x;
	if(x>9) write(x/10);
	putchar(x%10+'0');
}
void write(int x,char c){
	write(x);putchar(c);
}
void file(){
	freopen("a.txt","w",stdout);
}
const int N=1005;
int n,a[N],ans;
map<int,int> mp;
bool cmp(int x,int y){
	return abs(x)<abs(y)||(abs(x)==abs(y)&&x<y);
}
signed main(){
	freopen("T2.in","r",stdin);
	freopen("T2.out","w",stdout);
	n=read();
	for(int i=1;i<=n;i++) a[i]=read(),mp[a[i]]++;
	sort(a+1,a+1+n);
	n=unique(a+1,a+1+n)-(a+1);
	for(auto x:mp){
		if(x.second>=4) ans+=x.second*(x.second-1)*(x.second-2)*(x.second-3)/24;
	}
	for(auto x:mp){
		if(x.first>=0) continue;
		if(x.second>=2&&mp[-x.first]>=2) ans+=x.second*(x.second-1)/2*mp[-x.first]*(mp[-x.first]-1)/2;
	}
	for(int i=1;i<=n;i++){
		for(int j=i+1;j<=n;j++){
			if(a[i]==a[j]) continue;
			int d=a[j]-a[i];
			ans+=mp[a[i]]*mp[a[j]]*mp[a[j]+d]*mp[a[j]+2*d];
		}
	}
	sort(a+1,a+1+n,cmp);
	for(int i=1;i<=n;i++){
		for(int j=i+1;j<=n;j++){
			if(abs(a[i])==abs(a[j])||!a[i]||!a[j]) continue;
			int t1=a[j]*a[j],t2=t1*a[j];
			if(t1%a[i]||t2%(a[i]*a[i])) continue;
			ans+=mp[a[i]]*mp[a[j]]*mp[t1/a[i]]*mp[t2/(a[i]*a[i])];
		}
	}
	write(ans,'\n');
	return 0;
}
