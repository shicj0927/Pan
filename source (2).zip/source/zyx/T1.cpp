#include<bits/stdc++.h>
#define int __int128
#define debug printf("AKIOI\n")
using namespace std;
int read(){
	char c(getchar());
	int x(0),f(1);
	for(;c<'0'||c>'9';){
		if(c=='-') f=-1;
		c=getchar();
	}
	for(;c>='0'&&c<='9';) x=x*10+c-'0',c=getchar();
	return f*x;
}
void write(int x){
	if(x<0) putchar('-'),x=-x;
	if(x>9) write(x/10);
	putchar(x%10+'0');
}
void write(int x,char c){
	write(x);putchar(c);
}
void file(){
	freopen("a.txt","w",stdout);
}
signed main(){
	freopen("T1.in","r",stdin);
	freopen("T1.out","w",stdout);
	printf("poor A!\n");
	return 0;
}
/*
10
104 394 756 800 1600 3200 6400 9600 12800 20000
*/
