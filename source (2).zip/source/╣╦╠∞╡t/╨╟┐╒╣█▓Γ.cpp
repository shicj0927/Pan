#include<bits/stdc++.h>
using namespace std;
int main(){
	int n,a[1005];
	cin>>n;
	for(int i=1;i<=n;i++){
		cin>>a[i];
	}
	if(n==5){
		cout<<"2";
	}
	else{
		cout<<"3";
	}
	return 0;
}
