#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
typedef unsigned long long ull;
typedef double db;
typedef void vd;
typedef bool bl;
//#ifdef LOCAL
//#include"dbg.h"
//#else
//#define dbg(...) (__VA_ARGS__)
//#endif
//namespace Fread {
//  const int SIZE=1<<16;
//  char buf[SIZE],*S,*T;
//  inline char getchar() {
//      if(S==T) {
//          T=(S=buf)+fread(buf,1,SIZE,stdin);
//          if(S==T)return'\n';
//      }
//      return *S++;
//  }
//} namespace Fwrite {
//  const int SIZE=1<<16;
//  char buf[SIZE],*S=buf,*T=buf+SIZE;
//  inline void flush() {
//      fwrite(buf,1,S-buf,stdout);
//      S=buf;
//  } inline void putchar(char c) {
//      *S++=c;
//      if(S==T)flush();
//  } struct NTR {
//      ~NTR() {
//          flush();
//      }
//  } ztr;
//}
//#define getchar Fread::getchar
//#define putchar Fwrite::putchar
//#define Setprecision 10
//#define between ' '
//template<typename T>struct is_char {
//  static constexpr bool value=(std::is_same<T,char>::value||std::is_same<T,signed char>::value||std::is_same<T,unsigned char>::value);
//};
//template<typename T>struct is_integral_ex {
//  static constexpr bool value=(std::is_integral<T>::value||std::is_same<T,__int128>::value)&&!is_char<T>::value;
//};
//template<typename T>struct is_floating_point_ex {
//  static constexpr bool value=std::is_floating_point<T>::value||std::is_same<T,__float128>::value;
//};
//namespace Fastio {
//  struct Reader {
//      template<typename T>typename std::enable_if_t<std::is_class<T>::value,Reader&>operator>>(T&x) {
//          for(auto &y:x)*this>>y;
//          return *this;
//      } template<typename T>typename std::enable_if_t<is_integral_ex<T>::value,Reader&>operator>>(T&x) {
//          char c=getchar();
//          short f=1;
//          while(c<'0'||c>'9') {
//              if(c=='-')f*=-1;
//              c=getchar();
//          }
//          x=0;
//          while(c>='0'&&c<='9') {
//              x=(x<<1)+(x<<3)+(c^48);
//              c=getchar();
//          }
//          x*=f;
//          return *this;
//      } template<typename T>typename std::enable_if_t<is_floating_point_ex<T>::value,Reader&>operator>>(T&x) {
//          char c=getchar();
//          short f=1,s=0;
//          x=0;
//          T t=0;
//          while((c<'0'||c>'9')&&c!='.') {
//              if(c=='-')f*=-1;
//              c=getchar();
//          }
//          while(c>='0'&&c<='9'&&c!='.')x=x*10+(c^48),c=getchar();
//          if(c=='.')c=getchar();
//          else return x*=f,*this;
//          while(c>='0'&&c<='9')t=t*10+(c^48),s++,c=getchar();
//          while(s--)t/=10.0;
//          x=(x+t)*f;
//          return*this;
//      } template<typename T>typename std::enable_if_t<is_char<T>::value,Reader&>operator>>(T&c) {
//          c=getchar();
//          while(c=='\n'||c==' '||c=='\r')c=getchar();
//          return *this;
//      } Reader&operator>>(char*str) {
//          int len=0;
//          char c=getchar();
//          while(c=='\n'||c==' '||c=='\r')c=getchar();
//          while(c!='\n'&&c!=' '&&c!='\r')str[len++]=c,c=getchar();
//          str[len]='\0';
//          return*this;
//      } Reader&operator>>(std::string&str) {
//          char c=getchar();
//          while(c=='\n'||c==' '||c=='\r')c=getchar();
//          while(c!='\n'&&c!=' '&&c!='\r')str.push_back(c),c=getchar();
//          return*this;
//      } Reader() {}
//  } cin;
//  const char endl='\n';
//  struct Writer {
//      typedef __int128 mxdouble;
//      template<typename T>typename std::enable_if_t<std::is_class<T>::value,Writer&>operator<<(T x) {
//          for(auto &y:x)*this<<y<<between;
//          *this<<'\n';
//          return *this;
//      } template<typename T>typename std::enable_if_t<is_integral_ex<T>::value,Writer&>operator<<(T x) {
//          if(x==0)return putchar('0'),*this;
//          if(x<0)putchar('-'),x=-x;
//          static int sta[45];
//          int top=0;
//          while(x)sta[++top]=x%10,x/=10;
//          while(top)putchar(sta[top]+'0'),--top;
//          return*this;
//      } template<typename T>typename std::enable_if_t<is_floating_point_ex<T>::value,Writer&>operator<<(T x) {
//          if(x<0)putchar('-'),x=-x;
//          mxdouble _=x;
//          x-=(T)_;
//          static int sta[45];
//          int top=0;
//          while(_)sta[++top]=_%10,_/=10;
//          if(!top)putchar('0');
//          while(top)putchar(sta[top]+'0'),--top;
//          putchar('.');
//          for(int i=0; i<Setprecision; i++)x*=10;
//          _=x;
//          while(_)sta[++top]=_%10,_/=10;
//          for(int i=0; i<Setprecision-top; i++)putchar('0');
//          while(top)putchar(sta[top]+'0'),--top;
//          return*this;
//      } template<typename T>typename std::enable_if_t<is_char<T>::value,Writer&>operator<<(T c) {
//          putchar(c);
//          return*this;
//      } Writer&operator<<(char*str) {
//          int cur=0;
//          while(str[cur])putchar(str[cur++]);
//          return *this;
//      } Writer&operator<<(const char*str) {
//          int cur=0;
//          while(str[cur])putchar(str[cur++]);
//          return*this;
//      } Writer&operator<<(std::string str) {
//          int st=0,ed=str.size();
//          while(st<ed)putchar(str[st++]);
//          return*this;
//      } Writer() {}
//  } cout;
//}
//#define cin Fastio::cin
//#define cout Fastio::cout
//#define endl Fastio::endl
//#define double long double
//constexpr int inf=1e8,zro=0;
//constexpr double zrod=0,eps=1e-18;
//struct frac {
//  int fz,fm;
//  frac(int fz_=0,int fm_=1) {
//      fz=fz_,fm=fm_;
//  }
//  frac operator+(const frac &b)const {
//      return frac(fz*b.fm+fm*b.fz,fm*b.fm);
//  }
//  frac operator-(const frac &b)const {
//      return frac(fz*b.fm-fm*b.fz,fm*b.fm);
//  }
//  frac&reduce() {
//      int _=__gcd(fz,fm);
//      fz/=_,fm/=_;
//      return *this;
//  }
//  void print() {
//      /*cerr<<fz<<'/'<<fm<<endl;*/
//  }
//};
inline ll read() {
    ll s = 0, w = 1;
    char ch = getchar();
    while (ch < '0' || ch > '9') {
        if (ch == '-')
            w = -1;
        ch = getchar();
    }
    while (ch >= '0' && ch <= '9') s = s * 10 + ch - '0', ch = getchar();
    return s * w;
}
inline vd print(ll x) {
    if (x < 0) {
    	
        putchar('-');
        x = -x;
    }
    if (x >= 10)
        print(x / 10);
    putchar(x % 10 + '0');
    return;
}
ll n,q;
struct node{
	ll k;
	string v;
}a[5005];
map<string,ll>vis;
char c;
int main(){
	freopen("T3.in","r",stdin);
	freopen("T3.out","w",stdout);
	n=read(),q=read();
	for(ll i=1;i<=n;i++) a[i].k=read(),a[i].v="AAA";
	vis["AAA"]=n;
	while(q--){
		cin>>c;
		if(c=='W'){
			ll l=read(),r=read(),t=read();
			for(ll i=l;i<=r;i++)
				if(a[i].k>=t) a[i].k++;
				else a[i].k=-1;
		}
		else if(c=='C'){
			string s;
			cin>>s;
			ll p=read(),cnt=0;
			char t;
			for(ll i=s.size()-1;i>=0;i--)
				if(s[i]>='A'&&s[i]<='Z'){
					t=s[i];
					break;
				}
			for(ll i=1;i<=n;i++)
				if(a[i].v==s)
					cnt++;
			if(cnt<p) printf("ERR\n");
			else{
				print(p),printf("\n");
				for(ll i=1;i<=n;i++){
					if(a[i].v==s&&cnt<=p){
						ll j=1;
						string v=s+'-'+char(t+1);
						while(1){
							char f='0'+j;
							string op=v+f;
							if(!vis[op]) break;
							j++;
						}
						char f='0'+j;
						a[i].v=v+f;
						vis[s]-=p;
						vis[a[i].v]=p;
						cnt++;
					}
				}
			}
		}
		else if(c=='S'){
			ll p=read();
			if(a[p].k==-1) printf("ERR\n");
			else cout<<a[p].v,printf("\n");
		}
		else if(c=='A'){
			ll l=read(),r=read(),k=read(),cnt=0;
			for(ll i=l;i<=r;i++)
				if(a[i].k==-1) cnt++;
			if(cnt==0) printf("no add\n");
			else if(cnt==1) printf("Add %lld soldier\n",cnt);
			else printf("Add %lld soldiers\n",cnt);
		}
		else if(c=='E'){
			string s;
			cin>>s;
			if(vis[s]==0) printf("Oh no!\n");
			else print(vis[s]),printf("\n");
		}
	}
	return 0;
}
/*



*/
