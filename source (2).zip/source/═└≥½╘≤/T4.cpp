#include <bits/stdc++.h>
#define int long long

using namespace std;

const int N = 5e5 + 5;

int n, a[N], cnt[500], ansl = 1, ansr = 0;

inline void sol() {
	cin >> n;
	for (int i = 1; i <= n; i++) {
		cin >> a[i];
	}
	for (int l = 1; l <= n; l++) {
		memset(cnt, 0, sizeof cnt);
		int mx = -1, mxcnt = 0;
		for (int r = l; r <= n; r++) {
			cnt[a[r]]++;
			if (cnt[a[r]] > mx) {
				mx = cnt[a[r]];
				mxcnt = 1;
			} else if (cnt[a[r]] == mx) {
				mxcnt++;
			}
			if (mxcnt > 1 && r - l + 1 > ansr - ansl + 1) {
				ansl = l, ansr = r;
			}
		}
	}
	if (ansl == 1 && ansr == 0) {
		cout << -1;
		return;
	}
	cout << ansl << " " << ansr << "\n";
}

signed main() {
	freopen("T4.in", "r", stdin);
	freopen("T4.out", "w", stdout);
//	ios::sync_with_stdio(0);
//	cin.tie(0); cout.tie(0);
//	init();
	int T = 1;
//	cin >> T;
	while (T--) sol();
	return 0;
}
