#include <bits/stdc++.h>
#define int long long

using namespace std;

const int N = 505;

struct node {
	int id, xp;
	string s;
	bool is_d;
	
	bool friend operator < (const node &a, const node &b) {
		return a.id < b.id;
	}
};

struct node2 {
	vector<int> s;
	char d;
	int sum, id[15];
};

int n, m;
node a[N];
int idx = 1;
node2 b[N];

inline void W() {
	int l, r, t;
	cin >> l >> r >> t;
	int cz = 0, zw = 0;
	for (int i = l; i <= r; i++) {
		if (a[i].is_d) continue;
		cz++;
		if (a[i].xp < t) {
			a[i].is_d = 1;
			zw++;
		} else {
			a[i].xp++;
		}
	}
	cout << cz << " " << zw << "\n";
}

inline void C() {
	string t;
	int p;
	cin >> t >> p;
	t = t.substr(3, (int)t.size() - 3);
	int now = 1;
	while (t.size()) {
		now = b[now].id[t[2] - '0'];
		t = t.substr(3, (int)t.size() - 3);
	}
	if ((int)b[now].s.size() < p) {
		cout << "ERR\n";
		return;
	}
	sort(b[now].s.begin(), b[now].s.end());
	idx++;
	b[idx].d = b[now].d + 1;
	b[idx].sum = 0;
	b[now].sum++;
	b[now].id[b[now].sum] = idx;
	int ren = 0;
//	cout << "!! " << now << " " << b[now].sum << "\n";
	for (auto i : b[now].s) {
		ren++;
		if (ren > p) break;
		a[i] = node{a[i].id, a[i].xp, a[i].s + '-' + b[idx].d + char(b[now].sum + '0'), a[i].is_d};
		b[idx].s.push_back(i);
//		cout << "!!! ADD " << a[i].id << " " << a[i].xp << " " << a[i].s << " " << a[i].is_d << "\n";
	}
	vector<int> v(0);
	for (int i = p; i < (int)b[now].s.size(); i++) {
		v.push_back(b[now].s[i]);
	}
	b[now].s = v;
	int cnt = 0;
	for (auto i : b[idx].s) {
		cnt += !(a[i].is_d);
	}
	cout << cnt << "\n";
}

inline void S() {
	int p;
	cin >> p;
	if (a[p].is_d) {
		cout << "ERR\n";
		return;
	}
	cout << a[p].s << "\n";
}

inline void E() {
	string s;
	cin >> s;
	string t = s.substr(3, (int)t.size() - 3);
	int now = 1;
	while (t.size()) {
		now = b[now].id[t[2] - '0'];
		t = t.substr(3, (int)t.size() - 3);
	}
	int cnt = 0;
	for (auto i : b[now].s) {
		cnt += !(a[i].is_d);
	}
	if (cnt == 0) {
		cout << "Oh no!\n";
		return;
	}
	cout << cnt << "\n";
}

inline void A() {
	int l, r, k;
	cin >> l >> r >> k;
	int cnt = 0;
	for (int i = l; i <= r; i++) {
		if (!(a[i].is_d)) continue;
		cnt++;
		a[i].is_d = 0;
		a[i].xp = k;
	}
	if (cnt == 0) {
		cout << "no add\n";
		return;
	}
	cout << "Add " << cnt << " soldier";
	if (cnt > 1) cout << "s";
	cout << "\n";
}

inline void sol() {
	cin >> n >> m;
	b[1].d = 'A' - 1;
	b[1].sum = 0;
	for (int i = 1; i <= n; i++) {
		a[i].id = i;
		cin >> a[i].xp;
		a[i].s = "AAA";
		a[i].is_d = 0;
		b[1].s.push_back(i);
	}
	while (m--) {
		char op;
		cin >> op;
		if (op == 'W') {
			W();
		}
		if (op == 'C') {
			C();
		}
		if (op == 'S') {
			S();
		}
		if (op == 'E') {
			E();
		}
		if (op == 'A') {
			A();
		}
//		cout << "!  ";
//		for (int i = 1; i <= n; i++) {
//			cout << a[i].s << "  ";
//		}
//		cout << "\n";
	}
}

/*
10 10
1 5 7 8 9 2 3 4 6 7
C AAA 5
C AAA-A1 3
W 1 4 2
S 7
S 1
A 1 4 10
E AAA-A1-B1
W 1 4 10
E AAA-A1-B1
S 1
*/

signed main() {
	freopen("T3.in", "r", stdin);
	freopen("T3.out", "w", stdout);
	ios::sync_with_stdio(0);
	cin.tie(0); cout.tie(0);
//	init();
	int T = 1;
//	cin >> T;
	while (T--) sol();
	return 0;
}
