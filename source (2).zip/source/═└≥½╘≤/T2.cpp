#include <bits/stdc++.h>
#define int long long

using namespace std;

const int N = 1005;

int n, a[N], ans;
map<int, int> cnt;

/*
134592
*/

inline bool check(long double x) {
	return (x - (int)x < 1e-12);
}

inline void sol() {
	cin >> n;
	for (int i = 1; i <= n; i++) {
		cin >> a[i];
		cnt[a[i]]++;
	}
//	for (auto i : cnt) {
//		ans += i.second * (i.second - 1) * (i.second - 2) * (i.second - 3) / 24;
//	}
	for (auto i : cnt) {
		for (auto j : cnt) {
			if (i == j) continue;
			if (i.first > j.first) continue;
			int d = j.first - i.first;
			if (cnt.count(j.first + d) && cnt.count(j.first + d + d)) {
				ans += i.second * j.second * cnt[j.first + d] * cnt[j.first + d + d];
			}
		}
	}
	for (auto i : cnt) {
		for (auto j : cnt) {
			if (i == j) continue;
			if (i.first > j.first) continue;
			if (i.first == 0 || j.first == 0) continue;
			long double d = j.first / i.first;
			if (abs(d + 1) < 1e-12) {
				ans += i.second * (i.second - 1) * j.second * (j.second - 1) / 4;
			} else if (cnt.count(j.first * d) && cnt.count(j.first * d * d)) {
				if (check(j.first * d) && check(j.first * d * d))
				ans += i.second * j.second * cnt[j.first * d] * cnt[j.first * d * d];
			}
		}
	}
	cout << ans << "\n";
}

signed main() {
	freopen("T2.in", "r", stdin);
	freopen("T2.out", "w", stdout);
	ios::sync_with_stdio(0);
	cin.tie(0); cout.tie(0);
//	init();
	int T = 1;
//	cin >> T;
	while (T--) sol();
	return 0;
}
