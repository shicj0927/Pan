#include<bits/stdc++.h>
using namespace std;
int n;
long long ans,a[1005],cnt;
map<long long,long long> mp,mp1;
int main(){
	freopen("T2.in","r",stdin);
	freopen("T2.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++){
		scanf("%lld",&a[i]);
		mp[a[i]]++;
	}
	for(int i=1;i<=n;i++){
		for(int j=1;j<=n;j++){
			if(a[i]==a[j]) continue;
			long long d=a[j]-a[i];
			ans+=mp[a[j]+d]*mp[a[j]+2*d];
			cnt+=mp[a[j]+d]*mp[a[j]+2*d];
			if(a[i]==-a[j]) continue;
			if(a[i]==0||a[j]==0) continue;
			if(a[j]*a[j]%a[i]!=0||a[j]*a[j]*a[j]/a[i]%a[i]!=0) continue;
			ans+=mp[a[j]*a[j]/a[i]]*mp[a[j]*a[j]/a[i]*a[j]/a[i]];
		}
	}
	ans/=2;
//	cnt/=2;
//	cout<<cnt<<' '<<ans-cnt<<endl;
	for(int i=1;i<=n;i++){
		if(mp1[a[i]]||mp1[-a[i]]) continue;
		if(a[i]==0) continue;
		ans+=(mp[a[i]]*mp[-a[i]]*(mp[a[i]]-1)*(mp[-a[i]]-1))/4;
		mp1[a[i]]=1;
		mp1[-a[i]]=1;
	}
	for(int i=1;i<=n;i++){
		ans+=(mp[a[i]]*(mp[a[i]]-1)*(mp[a[i]]-2)*(mp[a[i]]-3))/24;
		mp[a[i]]=0;
	}
	printf("%lld",ans);
	return 0;
}
/*
5
1 2 4 8 16

10
104 394 756 800 1600 3200 6400 9600 12800 20000

20
1 2 3 4 5 6 7 8 9 10 -1 -2 -3 -4 -5 -6 -7 -8 -9 -10
*/
