#include<bits/stdc++.h>
using namespace std;
int n,m,k,led[1005],l[1005];
long long c[1005],ans=1e18,dp[2005][2005];
int main(){
	freopen("T1.in","r",stdin);
	freopen("T1.out","w",stdout);
	scanf("%d%d%d",&n,&m,&k);
	for(int i=1,a;i<=n;i++){
		scanf("%d",&a);
		led[a]=1;
	}
	for(int i=1;i<=k;i++) scanf("%d%lld",&l[i],&c[i]);
	for(int i=1;i<=m;i++) for(int j=0;j<(1<<k);j++) dp[i][j]=1e18;
	for(int i=1;i<=m;i++){
		if(!led[i]){
			for(int j=0;j<(1<<k);j++) dp[i][j]=dp[i-1][j];
		}
		else{
			for(int j=0;j<(1<<k);j++){
				for(int o=1;o<=k;o++){
					if(!(j&(1<<o))) continue;
					dp[i][j]=min(dp[i][j],dp[max(0,i-l[o])][j^(1<<o)]+c[o]);
				}
			}
		}
	}
	for(int i=0;i<(1<<k);i++){
		int cnt=0;
		for(int j=1;j<=k;j++)
			if((i&(1<<j))) cnt+=l[j];
		if(cnt>m) continue;
		ans=min(ans,dp[m][i]);
	}
	if(ans!=1e18) printf("%lld",ans);
	else printf("poor A!");
	return 0;
}
/*
5 24 6
1 2 3 12 13
1 2
3 3
2 4
5 1
10 100
20 500

10 50 10
4 7 6 5 50 33 34 35 27 28
50 100
49 110
10 5
5 1
3 1
20 50
70 5
109 4
30 666
25 114514
*/
