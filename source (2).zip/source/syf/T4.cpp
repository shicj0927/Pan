#include<bits/stdc++.h>
using namespace std;

int n,l,r,maxa;
int a[500005];
int s[205][500005];

bool ok(int L,int R){
	int k=0,f=0;
	for(int i=1;i<=maxa;i++){
		int tmp=s[i][R]-s[i][L-1];
		k=max(k,tmp);
	}
	for(int i=1;i<=maxa;i++){
		int tmp=s[i][R]-s[i][L-1];
		if(tmp==k) f++;
	}
	if(f>=2) return 1;
	else return 0;
}


bool check(int x){
	for(int i=1;i<=n-x+1;i++){
		if(ok(i,i+x-1)){
			l=i,r=i+x-1;
			return 1;
		}
	}
	return 0;
}


int main(){
	freopen("T4.in","r",stdin);
	freopen("T4.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++){
		scanf("%d",&a[i]);
		maxa=max(maxa,a[i]);
	}
	for(int i=1;i<=n;i++){
		for(int j=1;j<=maxa;j++){
			if(j==a[i]) s[j][i]=s[j][i-1]+1;
			else s[j][i]=s[j][i-1];
		}	
	}
	
	for(int i=n;i>=1;i--){
		if(check(i)){
			printf("%d %d",l,r);
			return 0;	
		}
	}	
	printf("-1");
	return 0;
}

