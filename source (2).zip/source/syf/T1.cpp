#include<bits/stdc++.h>
using namespace std;

int n,m,k,t;
long long ans=1e18;
int a[1005];
int l[1005];
long long c[1005];
int dp[1005][2005];
int cnt[1005];

int main(){
	freopen("T1.in","r",stdin);
	freopen("T1.out","w",stdout);
	scanf("%d%d%d",&n,&m,&k);
	for(int i=1;i<=n;i++){
		scanf("%d",&a[i]);
		cnt[a[i]]=1;
	}
	for(int i=1;i<=k;i++){
		scanf("%d%lld",&l[i],&c[i]);
	}
	dp[0][0]=1;
	for(int i=1;i<=m;i++){
		for(int j=0;j<(1<<k);j++){
			if(dp[i-1][j]==1&&cnt[i]!=1) dp[i][j]=1;
			else{
				for(int q=1;q<k;q++){
					if((j&(1<<q-1))==0) continue;
					if(i>=l[q]) dp[i][j]=dp[i-l[q]][j-(1<<q-1)];
					if(dp[i][j]) break;
				}	
			}
			
		}
	}
	for(int i=1;i<(1<<k);i++){
		if(dp[m][i]==1){
			long long tmp=0;
			for(int j=1;j<k;j++){
				if((i&(1<<j-1))!=0) tmp+=c[j];
			}
			if(ans>tmp) ans=tmp,t=i;
		}
	}
	if(ans!=1e18) printf("%lld",ans);
	else printf("poor A!");
	return 0;
}

/*
10 50 10
4 7 6 5 50 33 34 35 27 28
50 100
49 110
10 5
5 1
3 1
20 50

70 5
109 4
30 666
25 114514
*/
