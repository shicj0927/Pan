#include<bits/stdc++.h>
using namespace std;

int n;
double a[1005];
long long ans;

int main(){
	freopen("T2.in","r",stdin);
	freopen("T2.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++){
		scanf("%f",&a[i]);
		
	}
	for(int i=1;i<=n;i++){
		for(int j=1;j<=n;j++){
			for(int p=1;p<=n;p++){
				for(int q=1;q<=n;q++){
					if(i==j||i==p||i==q||j==p||j==q||p==q) continue;
					if(a[i]==a[j]&&a[j]==a[p]&&a[p]==a[q]){
						if(i<j&&j<p&&p<q) ans++;
					}else if(a[i]==1&&a[j]==-1&&a[p]==1&&a[1]==-1){
						if(i<j&&j<p&&p<q) ans++;
					}else{
						if(a[i]-a[j]==a[j]-a[p]&&a[j]-a[p]==a[p]-a[q]) ans++;
						double k1=(double)(a[i]/a[j]),k2=(double)(a[j]/a[p]),k3=(double)(a[p]/a[q]);
						if(abs(k1-k2)<=0.0000001&&abs(k2-k3)<=0.0000001) ans++;	
					}	
				}
			} 
		}
	}
	printf("%lld",ans/2);
	return 0;
}
/*
10
104 394 756 800 1600 3200 6400 9600 12800 2000
*/


