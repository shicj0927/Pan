#include<bits/stdc++.h>
using namespace std;

int n,q;
int a[505];

int main(){
	freopen("T3.in","r",stdin);
	freopen("T3.out","w",stdout);
	scanf("%d%d",&n,&q);
	for(int i=1;i<=n;i++){
		scanf("%d",&a[i]);
	}
	while(q--){
		char c;
		cin>>c;
		if(c=='W'){
			int l,r,t;
			int an1=0,an2=0;
			scanf("%d%d%d",&l,&r,&t);
			for(int i=l;i<=r;i++){
				if(a[i]==-1) continue;
				if(a[i]<t) a[i]=-1,an2++;
				else a[i]++;
				an1++;
			}
			printf("%d %d\n",an1,an2);
		}else{
			int an1=0;
			int l,r,k;
			scanf("%d%d%d",&l,&r,&k);
			for(int i=l;i<=r;i++){
				if(a[i]==-1) a[i]=k,an1++;
			}
			if(an1==0) printf("no add\n");
			else if(an1==1) printf("Add 1 soldier\n");
			else printf("Add %d soldiers\n",an1);
		}
	}
	return 0;
}

