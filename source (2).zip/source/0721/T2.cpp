#include<bits/stdc++.h>
using namespace std;
long long n,ans;
long long a[10010];
bool cmp(long long x,long long y){
	return x*x<y*y;
}
int main(){
	freopen("T2.in","r",stdin);
	freopen("T2.out","w",stdout);
    cin>>n;
    for(int i=1;i<=n;i++){
        cin>>a[i];
    }
    sort(a+1,a+1+n);
    for(int i=1;i<=n-3;i++){
        for(int j=i+1;j<=n-2;j++){
            int k=j+1;
            while(a[k]<2*a[j]-a[i]&&k<=n)k++;
            do{
            if(a[k]==2*a[j]-a[i]&&k<=n){
                int l=k+1;
                while(a[l]<2*a[k]-a[j]&&l<=n)l++;
                do{
                if(a[l]==2*a[k]-a[j]&&l<=n){
                	ans++;
                	
				}
                l++;
				}while(a[l-1]==a[l]);
            }
            k++;
			}while(a[k-1]==a[k]);
        }
    }
    sort(a+1,a+1+n,cmp);
    for(int i=1;i<=n-3;i++){
     	if(a[i]==0)continue;
        for(int j=i+1;j<=n-2;j++){
            int k=j+1;
            while(abs(a[j]*a[j])>abs(a[k]*a[i])&&k<=n)k++;
            do{
            if(a[j]*a[j]==a[k]*a[i]&&k<=n){
                int l=k+1;
                while(abs(a[k]*a[k])>abs(a[j]*a[l])&&l<=n)l++;
                do{
                if(a[k]*a[k]==a[j]*a[l]&&l<=n){ans++;
                }l++;
				}while(abs(a[l-1])==abs(a[l])&&l<=n);
			}
            k++;
			}while(abs(a[k-1])==abs(a[k])&&k<=n);
        }
    }
    cout<<ans<<endl;
    fclose(stdin);
    fclose(stdout);
    return 0;
}
