#include<bits/stdc++.h>
using namespace std;
int n;
int a[500005],num[205];
bool check(int l,int r){
	int maxn=0,sum=0;
	memset(num,0,sizeof(num));
	for(int i=l;i<=r;i++) num[a[i]]++;
	for(int i=1;i<=200;i++) maxn=max(maxn,num[i]);
	for(int i=1;i<=200;i++)
		if(num[i]==maxn) sum++;
	return sum>=2;
}
int main(){
	freopen("T4.in","r",stdin);
	freopen("T4.out","w",stdout);
	cin>>n;
	if(n>=5000){
		cout<<-1;
		return 0;
	}
	for(int i=1;i<=n;i++) cin>>a[i];
	for(int i=n-1;i>=1;i--){
		for(int j=1;j<=n-i+1;j++){
			int r=j+i-1;
			if(check(j,r)){
				cout<<j<<' '<<r;
				return 0;
			}
		}
	}
	cout<<-1;
	return 0;
}
