#include<bits/stdc++.h>
using namespace std;
int main(){
	freopen("T1.in","r",stdin);
	freopen("T1.out","w",stdout);
	cout<<"poor A!";
	return 0;
}
