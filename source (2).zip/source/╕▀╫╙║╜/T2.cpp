#include<bits/stdc++.h>
using namespace std;
int n;
int a[1005];
map<int,int> to;
long long ans;
int main(){
	freopen("T2.in","r",stdin);
	freopen("T2.out","w",stdout);
	cin>>n;
	for(int i=1;i<=n;i++){
		cin>>a[i];
		to[a[i]]++;
	}
	for(int i=1;i<=n;i++){
		if(to[a[i]]>=4) ans+=1LL*to[a[i]]*(to[a[i]]-1)*(to[a[i]]-2)*(to[a[i]]-3)/4/3/2;
		if(a[i]>0&&to[-a[i]]>=2&&to[a[i]]>=2) ans+=1LL*to[a[i]]*(to[a[i]]-1)/2*to[-a[i]]*(to[-a[i]]-1)/2;
	}
	sort(a+1,a+1+n);
	for(int i=1;i<n;i++){
		for(int j=i+1;j<=n;j++){
			int tmp1=a[j]-a[i];
			if(tmp1==0) continue;
			else if(to[a[j]+tmp1]&&to[a[j]+tmp1+tmp1])
				ans+=1LL*to[a[j]+tmp1]*to[a[j]+tmp1+tmp1];
			if(a[i]!=0&&a[j]!=0&&a[j]%a[i]==0){
				int tmp2=a[j]/a[i];
				if(tmp2==-1) continue;
				else if(to[a[j]*tmp2]&&to[a[j]*tmp2*tmp2]) ans+=1LL*to[a[j]*tmp2]*to[a[j]*tmp2*tmp2];
			}
		}
	}
	cout<<ans;
	return 0;
}
