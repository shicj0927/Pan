#include<bits/stdc++.h>
using namespace std;
#define int long long
int n,s[10001],ss[10001],ans;
map<int,int>mp;
map<int,int>mpp;
vector<int>nums;
vector<int>abss;
signed main(){
	freopen("T2.in","r",stdin);
	freopen("T2.out","w",stdout);
	cin>>n;
	for(int i=1;i<=n;i++){
		cin>>s[i];
		ss[i]=abs(s[i]);
		if(mp[s[i]]==0)nums.push_back(s[i]);
		if(mpp[ss[i]]==0)abss.push_back(ss[i]);
		mp[s[i]]++;
		mpp[ss[i]]++;
	}
	for(int i=0;i<nums.size();i++){
		for(int j=i+1;j<nums.size();j++){
			//等差
			int a=nums[i],b=nums[j];
			if(b<a)swap(a,b);
			if(a!=b){
				int cha=b-a;
				int c=b+cha,d=c+cha;
				ans+=mp[a]*mp[b]*mp[c]*mp[d];
			}
		}
	}
	for(int i=0;i<abss.size();i++){
		for(int j=i+1;j<abss.size();j++){
			//等比
			int a=abss[i],b=abss[j];
			if(a>b)swap(a,b);
			if(a!=b&&a&&b){
				int bi=b/a;
				if(a*bi!=b)continue;
				int c=b*bi;
				int d=c*bi;
				ans+=mpp[a]*mpp[b]*mpp[c]*mpp[d];
			}
		}
	}
	for(auto i:abss){
		if(mpp[i]>=4){
			ans+=mpp[i]*(mpp[i]-1)*(mpp[i]-2)*(mpp[i]-3)/2/4/3;
		}
	}
	cout<<ans<<endl;
	return 0;
}