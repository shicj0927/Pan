#include<bits/stdc++.h>
using namespace std;
int main(){
	freopen("T3.in","r",stdin);
	freopen("T3.out","w",stdout);
	int n,q;
	cin>>n>>q;
	while(q--){
		char x;
		cin>>x;
		if(x=='A'){
			cout<<"no add"<<endl;
		}
	}
	return 0;
}