#include<bits/stdc++.h>
using namespace std;
int n,a[600001],b[300],t=0,ll,rr;
int check(int x){
	int L=1,R=L+x-1;
	for(int i=L; i<=R; i++){
		b[a[i]]++;
	}
	int maxn=0,mj;
	for(int i=1; i<=300; i++){
		maxn=max(maxn,b[i]);
	}
	for(int i=1; i<=300; i++){
		if(b[i]==maxn) mj++;
	}
	if(mj>=2){
		ll=L,rr=R,t=1;
		return 1;
	} 
	
	for(int i=R+1; i<=n; i++){
		L++;
		b[a[L-1]]--;
		b[a[i]]++;
		int maxn=0,mj;
		for(int i=1; i<=300; i++){
			maxn=max(maxn,b[i]);
		}
		for(int i=1; i<=300; i++){
			if(b[i]==maxn) mj++;
		}
		if(mj>=2){
			ll=L;
			rr=i,t=1;
			return 1;
		} 
	}
}
int main(){
	freopen("��שͿɫ.in","r",stdin);
	freopen("��שͿɫ.out","w",stdout);
	int n;
	cin>>n;
	for(int i=1; i<=n; i++){
		cin>>a[i];
	}
	int l=1,r=n,mid=0;
	while(l<r){
		mid=(l+r)/2;
		if(check(mid)) l=mid;
		else r=mid-1;
	}
	if(!t) cout<<-1<<endl;
	else cout<<ll<<" "<<rr<<endl;
}
