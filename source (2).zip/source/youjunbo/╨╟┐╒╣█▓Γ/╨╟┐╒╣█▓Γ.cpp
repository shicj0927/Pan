#include<bits/stdc++.h>
using namespace std;
long long a[100001];
int n;
map<int,int> b,c,d,e;
int main(){
	freopen("�ǿչ۲�.in","r",stdin);
	freopen("�ǿչ۲�.out","w",stdout);
	int n;
	cin>>n;
	b.clear();
	c.clear();
	d.clear();
	e.clear();
	for(int i=1; i<=n; i++){
		cin>>a[i];
		if(a[i]>0) b[a[i]]++,d[a[i]]=0;
		else c[abs(a[i])]++,e[a[i]]=0;
	}
	sort(a+1,a+n+1);
	int sum=0;
	for(int i=1; i<=n; i++){
		for(int j=i+1; j<=n; j++){
			if(a[i]==a[j]&&(a[i]>0&&b[a[i]]>=4&&d[a[i]]==0||a[i]<=0&&c[-a[i]]>=4&&e[a[i]]==0)){
				if(a[i]>0) sum+=b[a[i]]*(b[a[i]]-1)*(b[a[i]]-2)*(b[a[i]]-3)/24;
				else sum+=c[-a[i]]*(c[-a[i]]-1)*(c[-a[i]]-2)*(c[-a[i]]-3)/24;
			}
			else if(2*a[j]-a[i]>0&&b[2*a[j]-a[i]]>0||2*a[j]-a[i]<=0&&c[-2*a[j]+a[i]]<=0){
				
				long long x=2*a[j]-a[i],y;
				if(x>0) y=b[x];
				else y=c[-x];
				if(2*x-a[j]>0&&b[2*x-a[j]]>0||2*x-a[j]<=0&&c[-2*x+a[j]]<=0){
					long long z;
					if(2*x-a[j]>0) z=b[2*x-a[j]];
					else z=c[-2*x+a[j]];
					sum+=y*z;
				}
			}
			else if(a[i]!=0&&a[j]!=0&&((a[j]*a[j])%a[i]==0&&a[j]*a[j]/a[i]>0&&b[a[j]*a[j]/a[i]]>0||(a[j]*a[j])%a[i]==0&&a[j]*a[j]/a[i]<=0&&c[-a[j]*a[j]/a[i]]<=0)){
				long long x=a[j]*a[j]/a[i],y;
				if(x>0) y=b[x];
				else y=c[-x];
				if(x*x/a[j]>0&&b[x*x/a[j]]>0||x*x/a[j]<=0&&c[-x*x/a[j]]<=0){
					long long z;
					if(x*x/a[j]>0) z=b[x*x/a[j]];
					else z=c[-x*x/a[j]];
					sum+=y*z;
				}
			}
		}
	}
	cout<<sum<<endl;
}
