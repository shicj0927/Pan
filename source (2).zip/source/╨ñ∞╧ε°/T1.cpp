#include<bits/stdc++.h>
using namespace std;
int n, m, k, a[1010], f[1010][15][2], ans=0x3f3f3f3f;
struct node {
	int l, c;
} b[15];
int main() {
	freopen("T1.in", "r", stdin);
	freopen("T1.out", "w", stdout);
	memset(f, 0x3f, sizeof f);
	cin>>n>>m>>k;
	for (int i=1; i<=n; i++) cin>>a[i];
	sort(a+1, a+1+n);
	for (int i=1; i<=n; i++) cin>>b[i].l>>b[i].c;
	for (int i=1; i<=n; i++) 
		for (int j=1; j<=k; j++) {
			for (int x=i-1; x>=1; x--) 
				if (a[x]>=a[i]-b[j].l) f[i][j][1]=min(f[i][j][1], f[x][j][0]+b[j].c);
				else break;
			for (int x=j-1; x>=1; x--) f[i][j][0]=min(f[i][j][0], f[i][j-1][1]);
			for (int x=i-1; x>=1; x--) 
				if (a[x]+b[j].l>=a[i]) f[i][j][0]=min(f[i][j][0], f[x][j][1]);
				else break;
		}
	for (int i=1; i<=k; i++) ans=min(ans, min(f[n][i][0], f[n][i][1]));
	cout<<ans;
	return 0;
}

