#include<bits/stdc++.h>
using namespace std;
#define int long long
#define ull unsigned long long
int n, a[1010], ans;
unordered_map<ull, int> mp;
pair<int, int> f(pair<int, int> p) {
	return make_pair(p.first/__gcd(p.first, p.second), p.second/__gcd(p.first, p.second));
}
pair<int, int> c(pair<int, int> P, pair<int, int> Q) {
	return f(make_pair(P.first*Q.first, P.second*Q.second));
}
bool cmp(int p, int q) {
	return abs(p)<abs(q);
}
signed main() { 
	freopen("T2.in", "r", stdin);
	freopen("T2.out", "w", stdout);
	cin>>n;
	for (int i=1; i<=n; i++) {
		cin>>a[i];
		mp[a[i]]++;
	}
	sort(a+1, a+1+n);  
	for (int i=1; i<=n; i++) {
		for (int j=i+1; j<=n; j++) {
			int x=a[j]-a[i];
			if (mp[a[j]+x]&&mp[a[j]+2*x]) ans++;
		}
	}
	sort(a+1, a+1+n, cmp);
	for (int i=1; i<=n; i++) {
		for (int j=i+1; j<=n; j++) {
			pair<int, int> y, l, r;
			if (a[i]!=0&&a[j]!=0) {
				y=f(make_pair(a[j], a[i]));
				l=c(make_pair(a[j], 1), y);
				r=c(l, y);
				if (a[i]==a[j]||a[i]+a[j]==0) {
					if (a[i]==a[j]) {
						if (mp[a[i]]>=4) ans++;
					} else {
						if (mp[a[i]]>=2&&mp[a[j]]>=2) ans++;
					}
				} else 
				if (l.second==1&&mp[l.first]&&r.second==1&&mp[r.first]) ans++;
			}
		}
	}
	cout<<ans;
	return 0;
}

