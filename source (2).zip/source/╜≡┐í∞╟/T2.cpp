#include<bits/stdc++.h>
using namespace std;
int main(){
	freopen("T2.in","r",stdin);
	freopen("T2.out","w",stdout);
	cout<<134596;
	return 0;
}
