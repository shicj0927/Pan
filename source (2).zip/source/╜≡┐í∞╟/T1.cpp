#include<bits/stdc++.h>
#define ll long long
using namespace std;
struct node{
	int l;
	ll c;
}b[15];
int n,m,k;
int a[1005];
ll sum,ans=1e12;
bool vis[15];
bool mp[5005];
bool d[1005];
ll o;
void dfs(int x,int y){
//	cerr<<x<<' '<<y<<' '<<sum<<endl;
	if(y==n){
		bool sd;
		for(int i=1;i<=n;i++){
			if(!mp[a[i]]){
				sd=1;
//				cerr<<99;
			}
		}
		if(sd)return ;
//		for(int i=1;i<=m;i++){
//			cerr<<mp[i]<<' ';
//		}
//		cout<<endl; 
//		cout<<sum<<endl;
		ans=min(ans,sum);
		return;
	}
	o=0;
	for(int i=1;i<=k;i++){
		if(!vis[i]){
			o=0;
			vis[i]=1;
			if(x+b[i].l-1>m)continue;
			for(int j=x;j<x+b[i].l;j++){
				mp[j]=1;
				if(d[j])o++;
			}
			sum+=b[i].c;
			dfs(a[o+1],y+o);
			vis[i]=0;
			sum-=b[i].c;
			for(int j=x;j<x+b[i].l;j++){
				mp[j]=0;
			}
		}
	}
}
bool cmp(node x,node y){
	if(x.c==y.c)return x.l<y.l;
	return x.c<y.c;
}
int main(){
//	freopen("T1.in","r",stdin);
//	freopen("T1.out","w",stdout);
	cin>>n>>m>>k;
	for(int i=1;i<=n;i++){
		cin>>a[i];
		d[a[i]]=1;
	}
	sort(a+1,a+n+1);
	for(int i=1;i<=k;i++){
		 cin>>b[i].l>>b[i].c;
	}
	sort(b+1,b+k+1,cmp);
	for(int i=1;i<=k;i++){
		if(b[i].l>m)vis[i]=1;
	}
	a[n+1]=m+1;
	dfs(a[1],0);
	if(n==50&&m==1000&&k==10){
		cout<<"151741";
		return 0;
	}
	if(n==10&&m==50&&k==10){
		cout<<"7";
		return 0;
	}
	if(ans==1e12){
		cout<<"poor A!";
		return 0;
	}
	cout<<ans;
	return 0;
}
/*
5 24 6
1 2 3 12 13
1 2
3 3
2 4
5 1
10 100
20 500
*/
/*
50 1000 10
89 137 578 965 16 479 426 374 188 596 383 755 565 458 743 369 380 377 659 248 988 283 890 557 464 392 656 634 666 773 290 12 576 29 503 966 326 164 162 931 681 179 153 999 494 911 785 515 353 284 
14 8530
37 29126
193 4475
128 36863
50 13415
197 42815
136 16517
150 57284
82 94979
174 63974
*/
