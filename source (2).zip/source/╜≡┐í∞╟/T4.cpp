#include<bits/stdc++.h>
using namespace std;
int n;
int a[500005];
int b[205];
int c[100005];
bool cmp(int x,int y){
	return x>y;
}
int main(){
	freopen("T4.in","r",stdin);
	freopen("T4.out","w",stdout);
	cin>>n;
	for(int i=1;i<=n;i++)
		cin>>a[i];
	for(int i=1;i<=n;i++){
		for(int j=n;j>=i+1;j--){
			memset(b,0,sizeof b);
			for(int k=i;k<=j;k++){
				b[a[k]]++;
			}
			sort(b+1,b+200+1,cmp);
			if(b[1]==b[2]&&b[1]!=0){
				cout<<i<<' '<<j;
				return 0;
			}
		}
	}
	cout<<-1;
	return 0;
}
