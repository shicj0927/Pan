#include<bits/stdc++.h>
#define int long long
using namespace std;
signed main(){
	freopen("T2.in","r",stdin);
	freopem("T2.out","w",stdout);
	cout<<0;
	return 0;
}

