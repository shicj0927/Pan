#include<bits/stdc++.h>
#define int long long
using namespace std;
int n,q,a[505],l,r,k;
char c;
signed main(){
	freopen("T3.in","r",stdin);
	freopen("T3.out","w",stdout);
	cin>>n>>q;
	for(int i=1;i<=n;i++) cin>>a[i];
	while(q--){
		cin>>c>>l>>r>>k;
		if(c=='W'){
			int op=0;
			for(int i=l;i<=r;i++){
				if(a[i]>=k) a[i]++;
				else a[i]=-1,op++;
			}
			cout<<r-l+1<<" "<<op<<endl;
		}
		else{
			int op=0;
			for(int i=l;i<=r;i++){
				if(a[i]==-1) op++,a[i]=k;
			}
			if(op==0) cout<<"no add"<<endl;
			else{
				cout<<"Add "<<op<<" soldier";
				if(op>2) cout<<"s";
				cout<<endl;
			}
		}
	}                                                                                                                                           
	return 0;
}
