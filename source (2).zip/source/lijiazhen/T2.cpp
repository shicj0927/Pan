#include<bits/stdc++.h>
using namespace std;
int n,ans;
long long a[1005];
int ok(long long t1,long long t2,long long t3,long long t4){
	if((t1+t4)==(t2+t3)&&(t1+t3)==2*t2)return 1;
	if(t1*t4==t2*t3&&abs(t1*t3)==t2*t2)return 1;
	return 0;
}
int main(){
	freopen("T2.in","r",stdin);
	freopen("T2.out","w",stdout);
	cin>>n;
	for(int i=0;i<n;i++){
		cin>>a[i];
	}
	sort(a,a+n);
	for(int i=0;i<n;i++){
		for(int j=i+1;j<n;j++){
			for(int k=j+1;k<n;k++){
				for(int l=k+1;l<=n;l++){
					ans+=ok(a[i],a[j],a[k],a[l]);
				}
			}
		}
	}
	cout<<ans;
	return 0;
}
