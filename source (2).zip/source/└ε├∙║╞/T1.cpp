#include<bits/stdc++.h>
using namespace std;
int n,m,k,a[501010],dp[2010][(1<<11)],l[501010],c[501010],vis[501010],ans=1e9;
int main(){//shichanghao NB
	freopen("T1.in","r",stdin);
	freopen("T1.out","w",stdout);
	cin>>n>>m>>k;
	memset(dp,0x3f,sizeof(dp));
	for(int i=0;i<(1<<k)-1;i++){
		dp[0][i]=0;
	}
	for(int i=1;i<=n;i++) scanf("%d",a+i),vis[a[i]]=1;
	sort(a+1,a+1+n);
	for(int i=1;i<=k;i++){
		cin>>l[i]>>c[i];
	}
	for(int p=1;p<=m;p++){
		for(int i=0;i<(1<<k)-1;i++){
			if(!vis[p]) dp[p][i]=dp[p-1][i];
			for(int j=1;j<=k;j++){
				if(i&(1<<j-1)){
					if(p>=l[j])dp[p][i]=min(dp[p][i],dp[p-l[j]][i^(1<<j-1)]+c[j]);
				}
			}
		}
	}
	for(int i=a[n];i<=m;i++){
		for(int j=1;j<(1<<k)-1;j++){
			ans=min(ans,dp[i][j]);
		}
	}cout<<ans<<endl;
	return 0;
}
