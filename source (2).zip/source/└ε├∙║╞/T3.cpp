#include<bits/stdc++.h>
using namespace std;
int n,m,a[101010],l,r,t;
struct soider{
	int c;
	string belong;
}s[101010];
struct rteam{
	int len,op;
	deque<int> num;
};
map<string,rteam> mp;
char c;
string team;
void kill(int l,int r,int t){
	int a1=0,a2=0;
	for(int i=l;i<=r;i++){
		if(s[i].c!=-1) a1++;
		else continue;
		if(s[i].c<t){
			s[i].c=-1;
			a2++;
		}else s[i].c++;
	}cout<<a1<<' '<<a2<<endl;
}
void creater(string team,int p){
	int n_op=mp[team].op+1,a1=0,a2=0;
	string name=team+"-"+char('A'+n_op-1)+char('0'+mp[team].len+1);
	int oop=mp[team].num.size();
	for(int i=0;i<oop;i++){
		if(s[mp[team].num[i]].c!=-1) a2++;
	}
	for(int i=1;i<=min(int(mp[team].num.size()),p);i++){
		int h=mp[team].num.front();
		mp[team].num.pop_front();
		mp[name].num.push_back(h);
		s[h].belong=name;
		if(s[h].c!=-1) a1++;
	}
	if(p>a2) cout<<"ERR\n";
	else cout<<a1<<endl;
	mp[team].len++;
	mp[name].op=n_op;
}
void add(int l,int r,int t){
	int x=0;
	for(int i=l;i<=r;i++){
		if(s[i].c==-1){
			x++;
			s[i].c=t;
		}
	}
	if(x==0){
		cout<<"no add\n";
	}else if(x==1){
		cout<<"Add 1 soldier\n"; 
	}else cout<<"Add "<<x<<" soldiers\n";
}
int main(){
	freopen("T3.in","r",stdin);
	freopen("T3.out","w",stdout);
	cin>>n>>m;
	for(int i=1;i<=n;i++){
		cin>>s[i].c;
		s[i].belong="AAA";
		mp["AAA"].num.push_back(i);
	}
	while(m--){
		cin>>c;
		if(c=='W'){
			cin>>l>>r>>t;
			kill(l,r,t);
		}
		if(c=='C'){
			cin>>team>>t;
			creater(team,t);
		}
		if(c=='S'){
			cin>>t;
			if(s[t].c==-1){
				cout<<"ERR\n";
			}else cout<<s[t].belong<<endl;
		}
		if(c=='E'){
			cin>>team;
			int a1=0;
			for(int i=0;i<mp[team].num.size();i++){
				if(s[mp[team].num[i]].c!=-1) a1++;
			}
			if(a1){
				cout<<a1<<endl;
			}else cout<<"Oh no!\n";
		}
		if(c=='A'){
			cin>>l>>r>>t;
			add(l,r,t);
		}
	}
	return 0;
}
