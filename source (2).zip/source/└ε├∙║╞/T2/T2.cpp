#include<bits/stdc++.h>
using namespace std;
int n,m,a[101010],sum;
map<int,int> mp;
map<pair<int,int>,int> vis;
int check(int i,int j){
	int c=a[j]-a[i];
	mp[a[i]]--;
	mp[a[j]]--;
	int w=0;
	c=(c%2==0?c/2:-1);
	if(c!=-1&&mp.count(a[i]+c)&&mp.count(a[j]+c)){
		w++;
	}
	int q=(a[j]%a[i]==0?a[j]/a[i]:-1);
	q=(q&&q>0&&sqrt(q)*sqrt(q)==q?sqrt(q):0);
	if(q&&mp.count(a[i]*q)&&mp.count(a[j]*q)){
		w++;
	}
	if(q&&mp.count(a[i]*(-q))&&mp.count(a[j]*(-q))){
		w++;
	}
	return w;
}
int main(){
//	freopen("T2.in","r",stdin);
//	freopen("T2.out","w",stdout);
	cin>>n;
	for(int i=1;i<=n;i++) cin>>a[i],mp[a[i]]++;
	sort(a+1,a+1+n);
	for(int i=1;i<n;i++){
		for(int j=i+1;j<=n;j++){
			sum+=check(i,j);
		}
	}cout<<sum;
	return 0;
}
