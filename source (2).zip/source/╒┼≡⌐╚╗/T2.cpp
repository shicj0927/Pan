#include<bits/stdc++.h>
using namespace std;
#define int long long
int n,a[1005],sum;
bool cmp(int x,int y){ return abs(x)<abs(y); }
signed main(){
	//freopen("T2������.in","r",stdin);
	freopen("T2.in","r",stdin);
	freopen("T2.out","w",stdout);
	cin>>n;
	for(int i=1;i<=n;i++) cin>>a[i];
	sort(a+1,a+n+1,cmp);
	for(int i=1;i<n-2;i++)
		for(int j=i+1;j<n-1;j++)
			for(int k=j+1;k<n;k++)
				for(int l=k+1;l<=n;l++)
					if(a[i]*a[k]==a[j]*a[j]&&a[j]*a[l]==a[k]*a[k]) sum++;
	sort(a+1,a+n+1);
	for(int i=1;i<n-2;i++)
		for(int j=i+1;j<n-1;j++)
			for(int k=j+1;k<n;k++)
				for(int l=k+1;l<=n;l++)
					if(a[i]+a[k]==a[j]+a[j]&&a[j]+a[l]==a[k]+a[k]) sum++;
	cout<<sum;
	fclose(stdin);
	fclose(stdout);
	return 0;
}
