#include<bits/stdc++.h>
using namespace std;
int n,m,k,a[1005];
struct node{ int l,c; } e[1005];
bool ton[1005];
int main(){
	freopen("T1.in","r",stdin);
	freopen("T1.out","w",stdout);
	cin>>n>>m>>k;
	for(int i=1;i<=n;i++) cin>>a[i];
	sort(a+1,a+n+1);
	for(int i=1;i<=k;i++) cin>>e[i].l>>e[i].c;
	cout<<"poor A!";
	fclose(stdin);
	fclose(stdout);
	return 0;
}
