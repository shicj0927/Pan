#include<bits/stdc++.h>
#define ll long long
using namespace std;
const ll N=1010;
ll n,i,j,k,x,y,ans,d,p,q;
ll a[N];
unordered_map<ll,ll>f,g;
bool cmp(ll i,ll j)
{
	return abs(i)<abs(j);
}
int main()
{
	freopen("T2.in","r",stdin);
	freopen("T2.out","w",stdout);
	scanf("%lld",&n);
	for(i=1;i<=n;i++)
	{
		scanf("%lld",&a[i]);
		f[a[i]]++;
	}
	sort(a+1,a+n+1);
	for(i=1;i<=n;i++)
		if(i==1||a[i]==a[i-1])
			k++;
		else
		{
			ans+=k*(k-1)*(k-2)*(k-3)/24;
			k=1;
		}
	ans+=k*(k-1)*(k-2)*(k-3)/24;
	for(i=1;i<=n;i++)
		if(a[i]>0&&a[i]!=a[i-1])
		{
			x=f[a[i]];
			if(f.find(-a[i])==f.end())y=0;
			else y=f[-a[i]];
			ans+=x*(x-1)/2*y*(y-1)/2;
		}
	for(i=1;i<=n;i++)
		for(j=i+1;j<=n;j++)
		{
			d=a[j]-a[i];
			if(d>0)
			{
				if(f.find(a[j]+d)==f.end())x=0;
				else x=f[a[j]+d];
				if(f.find(a[j]+d+d)==f.end())y=0;
				else y=f[a[j]+d+d];
				ans+=x*y;
			}
		}
	sort(a+1,a+n+1,cmp);
	for(i=1;i<=n;i++)
		for(j=i+1;j<=n;j++)
		{
			if(a[i]==0)continue;
			if((a[j]*a[j]*a[j])%(a[i]*a[i]))continue;
			p=a[j]*a[j]/a[i];q=a[j]*a[j]*a[j]/a[i]/a[i];
			if(a[j]!=a[i]&&a[j]!=-a[i])
			{
				if(f.find(p)==f.end())x=0;
				else x=f[p];
				if(f.find(q)==f.end())y=0;
				else y=f[q];
				ans+=x*y;
			}
		}
	printf("%lld",ans);
}
