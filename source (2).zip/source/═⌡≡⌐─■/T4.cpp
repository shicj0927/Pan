#include<bits/stdc++.h>
#define ll long long
using namespace std;
const ll N=500010;
ll n,m,i,j,k,Max,ans,l,r,tot,mid;
ll a[N],f[N];
bool check(ll x)
{
	for(ll i=1;i<=n-x+1;i++)
	{
		if((f[i+x-1]-f[i-1])*2==x)return 1;
	}
	return 0;
}
int main()
{
	freopen("T4.in","r",stdin);
	freopen("T4.out","w",stdout);
	scanf("%lld",&n);
	bool flag=1;
	for(i=1;i<=n;i++)
	{
		scanf("%lld",&a[i]);
		if(a[i]>2)flag=0;	
	}
	if(n<=10000)
	{
		for(i=1;i<=n;i++)
		{
			memset(f,0,sizeof(f));
			Max=0;tot=0;
			for(j=i;j<=n;j++)
			{
				f[a[j]]++;
				if(f[a[j]]>Max)
				{
					Max=f[a[j]];
					tot=1;
				}
				else if(f[a[j]]==Max)
					tot++;
				if(tot>=2)
				{
					if(j-i+1>ans)
					{
						ans=j-i+1;
						l=i;r=j;
					}
				}
			}	
		}
		if(ans==0)printf("-1");
		else printf("%lld %lld",l,r);
	}
	else if(flag)
	{
		srand(time(NULL));
		for(i=1;i<=n;i++)a[i]--;
		for(i=1;i<=n;i++)f[i]=f[i-1]+a[i];
		for(i=1;i<=100;i++)
		{
			l=1;r=rand()%n+n;
			while(l<=r)
			{
				mid=l+r>>1;
				if(check(mid))
				{
					ans=max(ans,mid);
					l=mid+1;
				}
				else r=mid-1;
			}
		}
		if(ans==0)printf("-1");
		else
		{
			for(i=1;i<=n-ans+1;i++)
			{
				if((f[i+ans-1]-f[i-1])*2==ans)
				{
					l=i;r=i+ans-1;break;
				}
			}
			printf("%lld %lld",l,r);
		}
	}
	else
	{
		printf("-1");
	}
}
