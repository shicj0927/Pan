#include<bits/stdc++.h>
using namespace std;
int n,q,a,b,c,ans1,ans2;
string s1,s2,s3;
char cc;
struct sd{
	int k;
	string nm,nxt;
}x[505];
int main(){
	//freopen("T3.in","r",stdin);
	//freopen("T3.out","w",stdout);
	cin>>n>>q;
	for(int i=1;i<=n;i++){
		cin>>x[i].k;
		x[i].nm="AAA";
	}
	x[1].nxt="-A1";
	for(int i=1;i<=q;i++){
		cin>>cc;
		if(cc=='W'){
			cin>>a>>b>>c;
			ans1=0;
			ans2=0;
			for(int j=a;j<=b;j++){
				if(x[j].k!=-1)ans1++;
				if(x[j].k<c){
					x[j].k=-1;
					ans2++;
				}else{
					x[j].k++;
				}
			}
			cout<<ans1<<" "<<ans2<<endl;
		}
		if(cc=='C'){
			cin>>s1>>a;
			ans1=0;
			ans2=0;
			for(int j=1;j<=n;j++){
				if(x[j].nm==s1){
					if(ans2==0){
						ans2=j;
						s3=s1+x[j].nxt;
						s2=char(x[j].nxt[1]+1);
						x[j].nxt="-"+s2+"1";
					}
					ans1++;
				}else{
					if(s2!=""){
						s2="";
						x[j].nxt[x[j].nxt.length()-1]++;
					}
				}
			}
			if(ans1<a){
				cout<<"ERR\n";
			}else{
				ans1=0;
				for(int j=ans2;j<=ans2+a-1;j++){
					if(x[j].k!=-1)ans1++;
					x[j].nm=s3;
				}
				cout<<ans1<<endl;
			}
		}
		if(cc=='S'){
			cin>>a;
			if(x[a].k==-1){
				cout<<"ERR\n";
			}else{
				cout<<x[a].nm<<endl;
			}
		}
		if(cc=='E'){
			cin>>s1;
			ans1=0;
			for(int j=1;j<=n;j++){
				if(x[j].k!=-1&&x[j].nm==s1)ans1++;
			}
			if(ans1==0){
				cout<<"Oh no!\n";
			}else{
				cout<<ans1<<endl;
			}
		}
		if(cc=='A'){
			cin>>a>>b>>c;
			ans1=0;
			for(int j=a;j<=b;j++){
				if(x[j].k==-1){
					ans1++;
					x[j].k=c;
				}
			}
			if(ans1==0){
				cout<<"no add\n";
			}else if(ans1==1){
				cout<<"Add 1 soldier\n";
			}else{
				cout<<"Add "<<ans1<<" soldiers\n";
			}
		}
	}
	return 0;
}
/*
10 21
20 38 182 114 104 66 12 90 3 2
W 1 10 300
E AAA
S 5
A 3 6 10
C AAA 3
C AAA 3
C AAA 4
A 1 10 20
C AAA-A1 1
C AAA-A1 4
C AAA-A1 1
C AAA-A1 1
C AAA-A1-B1 1
S 1
W 5 9 14
S 10
E AAA-A1-B1
E AAA-A1-B1-C1
C AAA-A2 2
E AAA-A2
S 4
*/
