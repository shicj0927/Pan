#include<bits/stdc++.h>
using namespace std;
int a[1010];
int dc(int a,int b,int c,int d){
	int u=b-a;
	if(b==a+u && c==b+u && d==c+u){
		return 1;
	}
	return 0;
}
int db(int a,int b,int c,int d){
	if(a==0 || b==0 || c==0 || d==0){
		return 0;
	}
	double u=b*1.0/a;
	if(a*u==b && b*u==c && c*u==d){
		return 1;
	}
	return 0;
}
int main(){
	freopen("T2.in","r",stdin);
	freopen("T2.out","w",stdout);
	int n;
	scanf("%d",&n);
	for(int i=1;i<=n;i++){
		scanf("%d",&a[i]);
	}
	int ans=0;
	for(int i=1;i<=n;i++){
		for(int j=1;j<=n;j++){
			for(int k=1;k<=n;k++){
				for(int c=1;c<=n;c++){
					if(i==j || i==k || i==c || j==k || j==c || k==c){
						continue;
					}
					if(dc(a[i],a[j],a[k],a[c])==1){
						ans+=4;
					}
					else if(db(a[i],a[j],a[k],a[c])==1){
						if((a[j]*1.0/a[i])<0){
							ans+=2;
						}
						else{
							ans+=4;
						}
					}
				}
			}
		}
	} 
	printf("%d\n",ans/8); 
	return 0;
}
